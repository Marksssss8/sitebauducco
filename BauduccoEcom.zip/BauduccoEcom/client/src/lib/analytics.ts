declare global {
  interface Window {
    dataLayer: any[];
    gtag: (...args: any[]) => void;
  }
}

export const initGA = () => {
  const measurementId = import.meta.env.VITE_GA_MEASUREMENT_ID;

  if (!measurementId) {
    console.warn('Missing required Google Analytics key: VITE_GA_MEASUREMENT_ID');
    return;
  }

  const script1 = document.createElement('script');
  script1.async = true;
  script1.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`;
  document.head.appendChild(script1);

  const script2 = document.createElement('script');
  script2.textContent = `
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '${measurementId}');
  `;
  document.head.appendChild(script2);
};

export const trackPageView = (url: string) => {
  if (typeof window === 'undefined' || !window.gtag) return;
  
  const measurementId = import.meta.env.VITE_GA_MEASUREMENT_ID;
  if (!measurementId) return;
  
  window.gtag('config', measurementId, {
    page_path: url
  });
};

export const trackEvent = (
  action: string, 
  category?: string, 
  label?: string, 
  value?: number
) => {
  if (typeof window === 'undefined' || !window.gtag) return;
  
  window.gtag('event', action, {
    event_category: category,
    event_label: label,
    value: value,
  });
};

// E-commerce specific events
export const trackViewItemList = (items: any[], listName?: string) => {
  trackEvent('view_item_list', 'ecommerce', listName);
};

export const trackSelectItem = (item: any) => {
  trackEvent('select_item', 'ecommerce', item.name);
};

export const trackViewItem = (item: any) => {
  trackEvent('view_item', 'ecommerce', item.name, item.price);
};

export const trackAddToCart = (item: any, quantity: number) => {
  trackEvent('add_to_cart', 'ecommerce', item.name, item.price * quantity);
};

export const trackRemoveFromCart = (item: any) => {
  trackEvent('remove_from_cart', 'ecommerce', item.name);
};

export const trackBeginCheckout = (cartTotal: number) => {
  trackEvent('begin_checkout', 'ecommerce', undefined, cartTotal);
};

export const trackAddShippingInfo = (shippingMethod: string) => {
  trackEvent('add_shipping_info', 'ecommerce', shippingMethod);
};

export const trackAddPaymentInfo = (paymentMethod: string) => {
  trackEvent('add_payment_info', 'ecommerce', paymentMethod);
};

export const trackPurchase = (orderId: string, total: number) => {
  trackEvent('purchase', 'ecommerce', orderId, total);
};

export const trackCouponApplied = (couponCode: string) => {
  trackEvent('coupon_applied', 'ecommerce', couponCode);
};

export const trackSearch = (searchTerm: string) => {
  trackEvent('search', 'engagement', searchTerm);
};
