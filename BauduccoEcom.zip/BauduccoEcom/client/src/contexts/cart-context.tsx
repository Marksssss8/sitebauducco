import { createContext, useContext, useState, useEffect, useCallback } from "react";
import type { CartItem, Cart } from "@shared/schema";
import { trackAddToCart, trackRemoveFromCart } from "@/lib/analytics";

interface CartContextType {
  cart: Cart;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  addItem: (item: Omit<CartItem, "quantity"> & { quantity?: number }) => void;
  removeItem: (sku: string) => void;
  updateQuantity: (sku: string, quantity: number) => void;
  clearCart: () => void;
  applyPromoCode: (code: string) => Promise<{ success: boolean; message: string }>;
  removePromoCode: (code: string) => void;
  itemCount: number;
}

const CART_STORAGE_KEY = "bauducco-cart";

const defaultCart: Cart = {
  id: crypto.randomUUID(),
  items: [],
  totals: {
    subtotal: 0,
    discount: 0,
    shipping: 0,
    total: 0,
  },
  appliedPromos: [],
};

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [cart, setCart] = useState<Cart>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          return defaultCart;
        }
      }
    }
    return defaultCart;
  });
  
  const [isCartOpen, setIsCartOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
  }, [cart]);

  const calculateTotals = useCallback((items: CartItem[], appliedPromos: string[]): Cart["totals"] => {
    const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
    
    // Simple discount calculation - in real app this would come from API
    let discount = 0;
    if (appliedPromos.includes("PRIMEIRA10")) {
      discount = subtotal * 0.1;
    } else if (appliedPromos.includes("FRETE20")) {
      discount = 20;
    }
    
    const shipping = subtotal >= 150 ? 0 : 15.90;
    const total = Math.max(0, subtotal - discount + shipping);
    
    return { subtotal, discount, shipping, total };
  }, []);

  const addItem = useCallback((newItem: Omit<CartItem, "quantity"> & { quantity?: number }) => {
    setCart(prev => {
      const existingIndex = prev.items.findIndex(item => item.sku === newItem.sku);
      let newItems: CartItem[];
      
      if (existingIndex >= 0) {
        newItems = prev.items.map((item, index) => 
          index === existingIndex 
            ? { ...item, quantity: item.quantity + (newItem.quantity || 1) }
            : item
        );
      } else {
        newItems = [...prev.items, { ...newItem, quantity: newItem.quantity || 1 }];
      }
      
      trackAddToCart(newItem, newItem.quantity || 1);
      
      return {
        ...prev,
        items: newItems,
        totals: calculateTotals(newItems, prev.appliedPromos),
      };
    });
    setIsCartOpen(true);
  }, [calculateTotals]);

  const removeItem = useCallback((sku: string) => {
    setCart(prev => {
      const item = prev.items.find(i => i.sku === sku);
      if (item) {
        trackRemoveFromCart(item);
      }
      
      const newItems = prev.items.filter(item => item.sku !== sku);
      return {
        ...prev,
        items: newItems,
        totals: calculateTotals(newItems, prev.appliedPromos),
      };
    });
  }, [calculateTotals]);

  const updateQuantity = useCallback((sku: string, quantity: number) => {
    if (quantity < 1) {
      removeItem(sku);
      return;
    }
    
    setCart(prev => {
      const newItems = prev.items.map(item =>
        item.sku === sku ? { ...item, quantity } : item
      );
      return {
        ...prev,
        items: newItems,
        totals: calculateTotals(newItems, prev.appliedPromos),
      };
    });
  }, [calculateTotals, removeItem]);

  const clearCart = useCallback(() => {
    setCart(defaultCart);
  }, []);

  const applyPromoCode = useCallback(async (code: string): Promise<{ success: boolean; message: string }> => {
    const upperCode = code.toUpperCase();
    
    // Validate promo code via API in real app
    const validCodes = ["PRIMEIRA10", "FRETE20", "NATAL15"];
    
    if (cart.appliedPromos.includes(upperCode)) {
      return { success: false, message: "Este cupom já foi aplicado" };
    }
    
    if (!validCodes.includes(upperCode)) {
      return { success: false, message: "Cupom inválido" };
    }
    
    setCart(prev => {
      const newPromos = [...prev.appliedPromos, upperCode];
      return {
        ...prev,
        appliedPromos: newPromos,
        totals: calculateTotals(prev.items, newPromos),
      };
    });
    
    return { success: true, message: "Cupom aplicado com sucesso!" };
  }, [cart.appliedPromos, calculateTotals]);

  const removePromoCode = useCallback((code: string) => {
    setCart(prev => {
      const newPromos = prev.appliedPromos.filter(p => p !== code);
      return {
        ...prev,
        appliedPromos: newPromos,
        totals: calculateTotals(prev.items, newPromos),
      };
    });
  }, [calculateTotals]);

  const itemCount = cart.items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <CartContext.Provider value={{
      cart,
      isCartOpen,
      setIsCartOpen,
      addItem,
      removeItem,
      updateQuantity,
      clearCart,
      applyPromoCode,
      removePromoCode,
      itemCount,
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
