import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Star, Truck, Shield } from "lucide-react";
import type { Product, NutritionalInfo } from "@shared/schema";

interface ProductTabsProps {
  product: Product;
}

export function ProductTabs({ product }: ProductTabsProps) {
  return (
    <Tabs defaultValue="description" className="w-full" data-testid="product-tabs">
      <TabsList className="w-full justify-start border-b rounded-none h-auto p-0 bg-transparent">
        <TabsTrigger
          value="description"
          className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
        >
          Descrição
        </TabsTrigger>
        <TabsTrigger
          value="nutrition"
          className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
        >
          Informação Nutricional
        </TabsTrigger>
        <TabsTrigger
          value="reviews"
          className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
        >
          Avaliações
        </TabsTrigger>
        <TabsTrigger
          value="shipping"
          className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-6 py-3"
        >
          Entrega
        </TabsTrigger>
      </TabsList>

      <TabsContent value="description" className="pt-6">
        <div
          className="prose prose-stone dark:prose-invert max-w-none"
          dangerouslySetInnerHTML={{ __html: product.descriptionHtml }}
        />
      </TabsContent>

      <TabsContent value="nutrition" className="pt-6">
        {product.nutritionalInfo ? (
          <NutritionalTable info={product.nutritionalInfo} />
        ) : (
          <p className="text-muted-foreground">
            Informação nutricional não disponível para este produto.
          </p>
        )}
      </TabsContent>

      <TabsContent value="reviews" className="pt-6">
        <ReviewsSection rating={product.rating} reviewCount={product.reviewCount} />
      </TabsContent>

      <TabsContent value="shipping" className="pt-6">
        <ShippingInfo />
      </TabsContent>
    </Tabs>
  );
}

function NutritionalTable({ info }: { info: NutritionalInfo }) {
  const rows = [
    { label: "Porção", value: info.servingSize },
    { label: "Calorias", value: `${info.calories} kcal` },
    { label: "Gorduras Totais", value: info.totalFat },
    { label: "Gorduras Saturadas", value: info.saturatedFat },
    { label: "Gorduras Trans", value: info.transFat },
    { label: "Colesterol", value: info.cholesterol },
    { label: "Sódio", value: info.sodium },
    { label: "Carboidratos Totais", value: info.totalCarbs },
    { label: "Fibra Alimentar", value: info.dietaryFiber },
    { label: "Açúcares", value: info.sugars },
    { label: "Proteínas", value: info.protein },
  ];

  return (
    <Card>
      <CardContent className="p-0">
        <table className="w-full">
          <thead>
            <tr className="border-b bg-muted/50">
              <th className="text-left py-3 px-4 font-semibold">Nutriente</th>
              <th className="text-right py-3 px-4 font-semibold">Quantidade por porção</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, index) => (
              <tr key={row.label} className={index < rows.length - 1 ? "border-b" : ""}>
                <td className="py-3 px-4">{row.label}</td>
                <td className="py-3 px-4 text-right">{row.value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </CardContent>
    </Card>
  );
}

function ReviewsSection({ rating, reviewCount }: { rating?: number; reviewCount?: number }) {
  const mockReviews = [
    {
      id: 1,
      author: "Maria S.",
      rating: 5,
      date: "15/11/2024",
      content: "Produto excelente! Chegou bem embalado e fresquinho. Super recomendo!",
    },
    {
      id: 2,
      author: "João P.",
      rating: 4,
      date: "10/11/2024",
      content: "Muito bom, minha família adorou. Entrega rápida.",
    },
    {
      id: 3,
      author: "Ana C.",
      rating: 5,
      date: "05/11/2024",
      content: "Delicioso! Compro sempre para as festas de fim de ano.",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Rating Summary */}
      <div className="flex items-center gap-6 p-4 bg-card rounded-lg">
        <div className="text-center">
          <div className="text-4xl font-bold text-primary">{rating?.toFixed(1) || "4.5"}</div>
          <div className="flex items-center justify-center gap-0.5 my-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star
                key={star}
                className={`h-4 w-4 ${
                  star <= Math.round(rating || 4.5)
                    ? "fill-yellow-400 text-yellow-400"
                    : "text-muted-foreground"
                }`}
              />
            ))}
          </div>
          <div className="text-sm text-muted-foreground">
            {reviewCount || 47} avaliações
          </div>
        </div>
        
        <div className="flex-1 space-y-1">
          {[5, 4, 3, 2, 1].map((stars) => {
            const percent = stars === 5 ? 70 : stars === 4 ? 20 : stars === 3 ? 7 : stars === 2 ? 2 : 1;
            return (
              <div key={stars} className="flex items-center gap-2">
                <span className="text-sm w-3">{stars}</span>
                <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-yellow-400 rounded-full"
                    style={{ width: `${percent}%` }}
                  />
                </div>
                <span className="text-sm text-muted-foreground w-8">{percent}%</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Reviews List */}
      <div className="space-y-4">
        {mockReviews.map((review) => (
          <Card key={review.id}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="font-medium">{review.author}</span>
                  <div className="flex items-center gap-0.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`h-3 w-3 ${
                          star <= review.rating
                            ? "fill-yellow-400 text-yellow-400"
                            : "text-muted-foreground"
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <span className="text-sm text-muted-foreground">{review.date}</span>
              </div>
              <p className="text-sm">{review.content}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

function ShippingInfo() {
  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4 flex items-start gap-4">
          <div className="p-2 rounded-full bg-primary/10">
            <Truck className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h4 className="font-medium mb-1">Frete Grátis</h4>
            <p className="text-sm text-muted-foreground">
              Em compras acima de R$ 150,00 para todo o Brasil. Prazo de entrega varia de acordo com a região.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 flex items-start gap-4">
          <div className="p-2 rounded-full bg-primary/10">
            <Shield className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h4 className="font-medium mb-1">Garantia de Entrega</h4>
            <p className="text-sm text-muted-foreground">
              Todos os produtos são embalados com cuidado para garantir que cheguem em perfeitas condições.
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="text-sm text-muted-foreground">
        <p className="mb-2">Prazos estimados de entrega:</p>
        <ul className="space-y-1 pl-4">
          <li>• Capitais: 2 a 5 dias úteis</li>
          <li>• Região Sul e Sudeste: 3 a 7 dias úteis</li>
          <li>• Demais regiões: 5 a 12 dias úteis</li>
        </ul>
      </div>
    </div>
  );
}
