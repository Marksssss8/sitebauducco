import { useState } from "react";
import { Truck, Loader2, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card } from "@/components/ui/card";
import type { ShippingOption } from "@shared/schema";

interface ShippingCalculatorProps {
  onSelectShipping?: (option: ShippingOption) => void;
  selectedOptionId?: string;
}

export function ShippingCalculator({ onSelectShipping, selectedOptionId }: ShippingCalculatorProps) {
  const [cep, setCep] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [shippingOptions, setShippingOptions] = useState<ShippingOption[]>([]);
  const [error, setError] = useState("");

  const formatCep = (value: string) => {
    const digits = value.replace(/\D/g, "");
    if (digits.length <= 5) return digits;
    return `${digits.slice(0, 5)}-${digits.slice(5, 8)}`;
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price);
  };

  const calculateShipping = async () => {
    const cleanCep = cep.replace(/\D/g, "");
    
    if (cleanCep.length !== 8) {
      setError("CEP inválido");
      return;
    }

    setIsLoading(true);
    setError("");

    try {
      // Mock shipping calculation - in production would call API
      await new Promise((resolve) => setTimeout(resolve, 800));

      const today = new Date();
      
      const options: ShippingOption[] = [
        {
          id: "sedex",
          name: "SEDEX",
          carrier: "Correios",
          price: 25.90,
          estimatedDays: 3,
          estimatedDelivery: new Date(today.getTime() + 3 * 24 * 60 * 60 * 1000).toLocaleDateString("pt-BR"),
        },
        {
          id: "pac",
          name: "PAC",
          carrier: "Correios",
          price: 15.90,
          estimatedDays: 7,
          estimatedDelivery: new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString("pt-BR"),
        },
        {
          id: "express",
          name: "Entrega Expressa",
          carrier: "Loggi",
          price: 35.90,
          estimatedDays: 1,
          estimatedDelivery: new Date(today.getTime() + 1 * 24 * 60 * 60 * 1000).toLocaleDateString("pt-BR"),
        },
      ];

      setShippingOptions(options);
    } catch (err) {
      setError("Erro ao calcular frete. Tente novamente.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectOption = (optionId: string) => {
    const option = shippingOptions.find((o) => o.id === optionId);
    if (option && onSelectShipping) {
      onSelectShipping(option);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <div className="flex-1">
          <Label htmlFor="shipping-cep" className="sr-only">CEP</Label>
          <Input
            id="shipping-cep"
            type="text"
            value={cep}
            onChange={(e) => setCep(formatCep(e.target.value))}
            placeholder="Digite seu CEP"
            maxLength={9}
            data-testid="input-shipping-cep"
          />
        </div>
        <Button
          onClick={calculateShipping}
          disabled={isLoading || cep.replace(/\D/g, "").length !== 8}
          data-testid="btn-calculate-shipping"
        >
          {isLoading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            "Calcular"
          )}
        </Button>
      </div>

      {error && (
        <p className="text-sm text-destructive">{error}</p>
      )}

      {shippingOptions.length > 0 && (
        <RadioGroup
          value={selectedOptionId}
          onValueChange={handleSelectOption}
          className="space-y-3"
        >
          {shippingOptions.map((option) => (
            <Card
              key={option.id}
              className={`p-4 cursor-pointer transition-all ${
                selectedOptionId === option.id
                  ? "border-primary ring-2 ring-primary/20"
                  : "hover-elevate"
              }`}
              onClick={() => handleSelectOption(option.id)}
            >
              <div className="flex items-center gap-3">
                <RadioGroupItem value={option.id} id={option.id} />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <Label
                      htmlFor={option.id}
                      className="font-medium cursor-pointer"
                    >
                      {option.name}
                    </Label>
                    <span className="font-semibold text-primary">
                      {formatPrice(option.price)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Truck className="h-4 w-4" />
                    <span>{option.carrier}</span>
                    <span>•</span>
                    <span>Entrega até {option.estimatedDelivery}</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </RadioGroup>
      )}

      <a
        href="https://buscacepinter.correios.com.br/"
        target="_blank"
        rel="noopener noreferrer"
        className="text-xs text-primary hover:underline"
      >
        Não sei meu CEP
      </a>
    </div>
  );
}
