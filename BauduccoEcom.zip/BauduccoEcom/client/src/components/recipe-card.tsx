import { Link } from "wouter";
import { Clock, Users, ChefHat } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import type { Recipe } from "@shared/schema";

interface RecipeCardProps {
  recipe: Recipe;
}

const difficultyLabels = {
  easy: "Fácil",
  medium: "Médio",
  hard: "Difícil",
};

const difficultyColors = {
  easy: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
  medium: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300",
  hard: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300",
};

export function RecipeCard({ recipe }: RecipeCardProps) {
  const totalTime = recipe.prepTime + recipe.cookTime;

  return (
    <Card 
      className="group overflow-visible hover-elevate transition-all duration-300"
      data-testid={`card-recipe-${recipe.id}`}
    >
      <Link href={`/blog/recipes/${recipe.slug}`}>
        <div className="relative aspect-video overflow-hidden rounded-t-md">
          <img
            src={recipe.image}
            alt={recipe.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            loading="lazy"
          />
          
          {/* Overlay on hover */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          
          {/* Badges */}
          <div className="absolute top-3 left-3 flex gap-2">
            <Badge className={difficultyColors[recipe.difficulty]}>
              {difficultyLabels[recipe.difficulty]}
            </Badge>
            {recipe.featured && (
              <Badge variant="secondary">Destaque</Badge>
            )}
          </div>

          {/* Time badge */}
          <div className="absolute bottom-3 left-3 flex items-center gap-1.5 bg-black/70 text-white px-2.5 py-1 rounded-full text-sm">
            <Clock className="h-3.5 w-3.5" />
            <span>{totalTime} min</span>
          </div>
        </div>

        <CardContent className="p-4">
          {/* Categories */}
          {recipe.categories.length > 0 && (
            <p className="text-xs text-muted-foreground mb-1.5 uppercase tracking-wide">
              {recipe.categories[0]}
            </p>
          )}

          {/* Title */}
          <h3 className="font-semibold text-lg leading-tight line-clamp-2 mb-2 group-hover:text-primary transition-colors">
            {recipe.title}
          </h3>

          {/* Description */}
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
            {recipe.description}
          </p>

          {/* Meta Info */}
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <Clock className="h-4 w-4" />
              <span>Preparo: {recipe.prepTime} min</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Users className="h-4 w-4" />
              <span>{recipe.servings} porções</span>
            </div>
          </div>
        </CardContent>
      </Link>
    </Card>
  );
}
