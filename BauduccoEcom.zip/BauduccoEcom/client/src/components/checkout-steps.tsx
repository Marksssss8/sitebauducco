import { Check, MapPin, Truck, CreditCard, ClipboardCheck } from "lucide-react";

interface CheckoutStepsProps {
  currentStep: number;
}

const steps = [
  { id: 1, name: "Endereço", icon: MapPin, testId: "checkout-step-address" },
  { id: 2, name: "Entrega", icon: Truck, testId: "checkout-step-shipping" },
  { id: 3, name: "Pagamento", icon: CreditCard, testId: "checkout-step-payment" },
  { id: 4, name: "Revisão", icon: ClipboardCheck, testId: "checkout-step-review" },
];

export function CheckoutSteps({ currentStep }: CheckoutStepsProps) {
  return (
    <nav aria-label="Progresso do checkout" className="mb-8">
      <ol className="flex items-center justify-between">
        {steps.map((step, index) => {
          const isCompleted = step.id < currentStep;
          const isCurrent = step.id === currentStep;
          const isUpcoming = step.id > currentStep;

          return (
            <li
              key={step.id}
              className="flex-1 flex items-center"
              data-testid={step.testId}
            >
              <div className="flex flex-col items-center w-full">
                {/* Connector Line (before) */}
                <div className="flex items-center w-full">
                  {index > 0 && (
                    <div
                      className={`h-1 flex-1 transition-colors duration-300 ${
                        isCompleted || isCurrent ? "bg-primary" : "bg-muted"
                      }`}
                    />
                  )}
                  
                  {/* Step Circle */}
                  <div
                    className={`relative flex items-center justify-center w-10 h-10 rounded-full border-2 transition-all duration-300 ${
                      isCompleted
                        ? "bg-primary border-primary text-primary-foreground"
                        : isCurrent
                        ? "border-primary bg-background text-primary"
                        : "border-muted bg-background text-muted-foreground"
                    }`}
                  >
                    {isCompleted ? (
                      <Check className="h-5 w-5" />
                    ) : (
                      <step.icon className="h-5 w-5" />
                    )}
                  </div>

                  {/* Connector Line (after) */}
                  {index < steps.length - 1 && (
                    <div
                      className={`h-1 flex-1 transition-colors duration-300 ${
                        isCompleted ? "bg-primary" : "bg-muted"
                      }`}
                    />
                  )}
                </div>

                {/* Step Label */}
                <span
                  className={`mt-2 text-xs md:text-sm font-medium transition-colors duration-300 ${
                    isCompleted || isCurrent
                      ? "text-primary"
                      : "text-muted-foreground"
                  }`}
                >
                  {step.name}
                </span>
              </div>
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
