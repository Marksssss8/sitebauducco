import { useState, useEffect } from "react";
import { X, Gift, Mail, Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

const MODAL_STORAGE_KEY = "bauducco-newsletter-shown";
const MODAL_DELAY = 5000; // 5 seconds

export function NewsletterModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const hasSeenModal = localStorage.getItem(MODAL_STORAGE_KEY);
    
    if (!hasSeenModal) {
      const timer = setTimeout(() => {
        setIsOpen(true);
      }, MODAL_DELAY);

      return () => clearTimeout(timer);
    }
  }, []);

  const handleClose = () => {
    setIsOpen(false);
    localStorage.setItem(MODAL_STORAGE_KEY, "true");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email.trim()) return;

    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    
    setIsSubmitting(false);
    handleClose();
    
    toast({
      title: "Cadastro realizado!",
      description: "Você receberá seu cupom de 10% por e-mail em breve.",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent 
        className="max-w-md p-0 overflow-hidden"
        data-testid="modal-subscribe"
      >
        {/* Header with gradient */}
        <div className="relative bg-gradient-to-br from-primary to-primary/80 text-primary-foreground p-8 text-center">
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-2 right-2 text-primary-foreground/80 hover:text-primary-foreground hover:bg-white/10"
            onClick={handleClose}
            aria-label="Fechar"
          >
            <X className="h-5 w-5" />
          </Button>
          
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/20 mb-4">
            <Gift className="h-8 w-8" />
          </div>
          
          <DialogTitle className="text-2xl font-bold mb-2">
            Ganhe 10% OFF
          </DialogTitle>
          <DialogDescription className="text-primary-foreground/90 text-base">
            na sua primeira compra
          </DialogDescription>
        </div>

        {/* Form */}
        <div className="p-6">
          <p className="text-center text-muted-foreground mb-6">
            Cadastre seu e-mail e receba ofertas exclusivas, novidades e receitas deliciosas!
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Seu melhor e-mail"
                className="pl-10"
                required
                data-testid="input-modal-email"
              />
            </div>
            
            <Button
              type="submit"
              className="w-full"
              size="lg"
              disabled={isSubmitting}
              data-testid="btn-modal-subscribe"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Cadastrando...
                </>
              ) : (
                "Quero meu cupom!"
              )}
            </Button>
          </form>

          <p className="text-xs text-center text-muted-foreground mt-4">
            Ao cadastrar você concorda com nossa{" "}
            <a href="/support#privacidade" className="underline hover:text-foreground">
              Política de Privacidade
            </a>
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
