import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface PromoBannerProps {
  title: string;
  subtitle?: string;
  ctaText: string;
  ctaLink: string;
  backgroundImage: string;
  variant?: "hero" | "section";
  align?: "left" | "center" | "right";
}

export function PromoBanner({
  title,
  subtitle,
  ctaText,
  ctaLink,
  backgroundImage,
  variant = "section",
  align = "center",
}: PromoBannerProps) {
  const alignmentClasses = {
    left: "items-start text-left",
    center: "items-center text-center",
    right: "items-end text-right",
  };

  const isHero = variant === "hero";

  return (
    <section
      className={`relative overflow-hidden ${
        isHero ? "min-h-[500px] md:min-h-[600px]" : "min-h-[300px] md:min-h-[400px]"
      }`}
      data-testid="promo-banner"
    >
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${backgroundImage})` }}
      />
      
      {/* Dark Wash Gradient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/30" />
      
      {/* Content */}
      <div className={`relative h-full flex flex-col justify-center ${alignmentClasses[align]} max-w-7xl mx-auto px-4 md:px-8 py-12 md:py-16`}>
        <div className={`max-w-2xl ${align === "center" ? "mx-auto" : ""}`}>
          {/* Title */}
          <h2
            className={`font-semibold text-white mb-4 ${
              isHero
                ? "text-4xl md:text-5xl lg:text-6xl"
                : "text-2xl md:text-3xl lg:text-4xl"
            }`}
          >
            {title}
          </h2>

          {/* Subtitle */}
          {subtitle && (
            <p
              className={`text-white/90 mb-6 ${
                isHero ? "text-lg md:text-xl" : "text-base md:text-lg"
              }`}
            >
              {subtitle}
            </p>
          )}

          {/* CTA Button - with blurred background for visibility on any image */}
          <Button
            size={isHero ? "lg" : "default"}
            className="gap-2 bg-primary hover:bg-primary/90 backdrop-blur-sm"
            asChild
          >
            <Link href={ctaLink}>
              {ctaText}
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}

interface TopBannerProps {
  message: string;
  linkText?: string;
  linkHref?: string;
  onDismiss?: () => void;
}

export function TopBanner({ message, linkText, linkHref, onDismiss }: TopBannerProps) {
  return (
    <div className="bg-primary text-primary-foreground text-center py-2 px-4 text-sm">
      <span>{message}</span>
      {linkText && linkHref && (
        <>
          {" "}
          <Link href={linkHref} className="underline font-medium hover:no-underline">
            {linkText}
          </Link>
        </>
      )}
    </div>
  );
}
