import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { Search, X, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { trackSearch } from "@/lib/analytics";

interface SearchBarProps {
  autoFocus?: boolean;
  onClose?: () => void;
}

interface SearchSuggestion {
  type: "product" | "category" | "recipe";
  id: string;
  name: string;
  image?: string;
  href: string;
}

export function SearchBar({ autoFocus, onClose }: SearchBarProps) {
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<SearchSuggestion[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [, navigate] = useLocation();
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (autoFocus && inputRef.current) {
      inputRef.current.focus();
    }
  }, [autoFocus]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    const searchDebounce = setTimeout(() => {
      if (query.length >= 2) {
        fetchSuggestions(query);
      } else {
        setSuggestions([]);
        setIsOpen(false);
      }
    }, 300);

    return () => clearTimeout(searchDebounce);
  }, [query]);

  const fetchSuggestions = async (searchQuery: string) => {
    setIsLoading(true);
    try {
      // Mock suggestions - in production this would call the API
      const mockSuggestions: SearchSuggestion[] = [
        {
          type: "product",
          id: "1",
          name: "Panettone Tradicional 500g",
          image: "https://placehold.co/60x60/fef3c7/92400e?text=P",
          href: "/product/panettone-tradicional-500g",
        },
        {
          type: "product",
          id: "2",
          name: "Chocottone Gotas de Chocolate",
          image: "https://placehold.co/60x60/fef3c7/92400e?text=C",
          href: "/product/chocottone-gotas-chocolate",
        },
        {
          type: "category",
          id: "cat1",
          name: "Panettones",
          href: "/products?category=panettones",
        },
        {
          type: "recipe",
          id: "rec1",
          name: "Rabanada de Panettone",
          image: "https://placehold.co/60x60/fef3c7/92400e?text=R",
          href: "/blog/recipes/rabanada-panettone",
        },
      ].filter((s) =>
        s.name.toLowerCase().includes(searchQuery.toLowerCase())
      );

      setSuggestions(mockSuggestions);
      setIsOpen(mockSuggestions.length > 0);
    } catch (error) {
      console.error("Error fetching suggestions:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      trackSearch(query);
      navigate(`/products?q=${encodeURIComponent(query)}`);
      setIsOpen(false);
      onClose?.();
    }
  };

  const handleSuggestionClick = (suggestion: SearchSuggestion) => {
    trackSearch(suggestion.name);
    navigate(suggestion.href);
    setIsOpen(false);
    setQuery("");
    onClose?.();
  };

  const clearSearch = () => {
    setQuery("");
    setSuggestions([]);
    setIsOpen(false);
    inputRef.current?.focus();
  };

  return (
    <div ref={containerRef} className="relative w-full md:w-80">
      <form onSubmit={handleSearch} className="relative">
        <Input
          ref={inputRef}
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Buscar produtos, receitas..."
          className="pr-20 pl-10"
          data-testid="search-input"
          aria-label="Buscar"
        />
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <div className="absolute right-1 top-1/2 -translate-y-1/2 flex items-center gap-1">
          {query && (
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={clearSearch}
              aria-label="Limpar busca"
            >
              <X className="h-3.5 w-3.5" />
            </Button>
          )}
          <Button
            type="submit"
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            data-testid="btn-search"
            disabled={isLoading}
            aria-label="Buscar"
          >
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Search className="h-4 w-4" />
            )}
          </Button>
        </div>
      </form>

      {/* Suggestions Dropdown */}
      {isOpen && suggestions.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-popover border border-popover-border rounded-md shadow-lg overflow-hidden z-50">
          <ul className="py-2">
            {suggestions.map((suggestion) => (
              <li key={`${suggestion.type}-${suggestion.id}`}>
                <button
                  type="button"
                  onClick={() => handleSuggestionClick(suggestion)}
                  className="w-full flex items-center gap-3 px-4 py-2.5 hover-elevate transition-colors text-left"
                  data-testid={`suggestion-${suggestion.id}`}
                >
                  {suggestion.image ? (
                    <img
                      src={suggestion.image}
                      alt=""
                      className="w-10 h-10 rounded object-cover"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded bg-muted flex items-center justify-center">
                      <Search className="h-4 w-4 text-muted-foreground" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{suggestion.name}</p>
                    <p className="text-xs text-muted-foreground capitalize">
                      {suggestion.type === "product" && "Produto"}
                      {suggestion.type === "category" && "Categoria"}
                      {suggestion.type === "recipe" && "Receita"}
                    </p>
                  </div>
                </button>
              </li>
            ))}
          </ul>
          <div className="border-t px-4 py-2">
            <button
              type="button"
              onClick={handleSearch}
              className="text-sm text-primary hover:underline"
            >
              Ver todos os resultados para "{query}"
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
