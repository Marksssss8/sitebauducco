import { Link } from "wouter";
import { ShoppingCart, Eye, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useCart } from "@/contexts/cart-context";
import { useToast } from "@/hooks/use-toast";
import type { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
  showQuickAdd?: boolean;
}

export function ProductCard({ product, showQuickAdd = true }: ProductCardProps) {
  const { addItem } = useCart();
  const { toast } = useToast();

  const defaultVariant = product.variants[0];
  const hasDiscount = defaultVariant.compareAtPrice && defaultVariant.compareAtPrice > defaultVariant.price;
  const discountPercent = hasDiscount
    ? Math.round((1 - defaultVariant.price / defaultVariant.compareAtPrice!) * 100)
    : 0;

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    addItem({
      sku: defaultVariant.sku,
      productId: product.id,
      name: product.name,
      image: product.images[0] || "https://placehold.co/300x300/fef3c7/92400e?text=Produto",
      variant: defaultVariant.name,
      price: defaultVariant.price,
      compareAtPrice: defaultVariant.compareAtPrice,
    });

    toast({
      title: "Adicionado ao carrinho",
      description: product.name,
    });
  };

  return (
    <Card className="group overflow-visible hover-elevate transition-all duration-300" data-testid={`card-product-${product.id}`}>
      <Link href={`/product/${product.slug}`}>
        <div className="relative aspect-[4/3] overflow-hidden rounded-t-md">
          <img
            src={product.images[0] || "https://placehold.co/400x300/fef3c7/92400e?text=Produto"}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            loading="lazy"
          />
          
          {/* Badges */}
          <div className="absolute top-2 left-2 flex flex-col gap-1">
            {hasDiscount && (
              <Badge className="bg-destructive text-destructive-foreground">
                -{discountPercent}%
              </Badge>
            )}
            {product.featured && (
              <Badge variant="secondary">Destaque</Badge>
            )}
            {product.availability === "out_of_stock" && (
              <Badge variant="secondary" className="bg-muted">Esgotado</Badge>
            )}
          </div>

          {/* Quick Actions - visible on hover */}
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
            <div className="flex gap-2">
              <Button
                variant="secondary"
                size="icon"
                className="h-10 w-10 rounded-full shadow-lg"
                aria-label="Ver detalhes"
              >
                <Eye className="h-4 w-4" />
              </Button>
              {showQuickAdd && product.availability === "in_stock" && (
                <Button
                  size="icon"
                  className="h-10 w-10 rounded-full shadow-lg"
                  onClick={handleAddToCart}
                  data-testid={`btn-quick-add-${product.id}`}
                  aria-label="Adicionar ao carrinho"
                >
                  <ShoppingCart className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </div>

        <CardContent className="p-4">
          {/* Categories */}
          {product.categories.length > 0 && (
            <p className="text-xs text-muted-foreground mb-1 uppercase tracking-wide">
              {product.categories[0]}
            </p>
          )}

          {/* Title */}
          <h3 className="font-medium leading-tight line-clamp-2 mb-2 group-hover:text-primary transition-colors">
            {product.name}
          </h3>

          {/* Rating */}
          {product.rating && (
            <div className="flex items-center gap-1 mb-2">
              <Star className="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" />
              <span className="text-sm font-medium">{product.rating.toFixed(1)}</span>
              {product.reviewCount && (
                <span className="text-xs text-muted-foreground">
                  ({product.reviewCount})
                </span>
              )}
            </div>
          )}

          {/* Price */}
          <div className="flex items-baseline gap-2 flex-wrap">
            {hasDiscount && (
              <span className="text-sm text-muted-foreground line-through">
                {formatPrice(defaultVariant.compareAtPrice!)}
              </span>
            )}
            <span className="text-lg font-bold text-primary">
              {formatPrice(defaultVariant.price)}
            </span>
          </div>

          {/* Installments hint */}
          <p className="text-xs text-muted-foreground mt-1">
            ou 3x de {formatPrice(defaultVariant.price / 3)} sem juros
          </p>
        </CardContent>
      </Link>
    </Card>
  );
}
