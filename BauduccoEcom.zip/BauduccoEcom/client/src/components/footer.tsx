import { Link } from "wouter";
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";

const footerLinks = {
  products: [
    { name: "Panettones", href: "/products?category=panettones" },
    { name: "Biscoitos", href: "/products?category=biscoitos" },
    { name: "Bolos", href: "/products?category=bolos" },
    { name: "Torradas", href: "/products?category=torradas" },
    { name: "Lançamentos", href: "/products?tag=lancamento" },
  ],
  institutional: [
    { name: "Nossa História", href: "/about" },
    { name: "Sustentabilidade", href: "/about#sustentabilidade" },
    { name: "Trabalhe Conosco", href: "/about#carreiras" },
    { name: "Imprensa", href: "/about#imprensa" },
  ],
  support: [
    { name: "Central de Ajuda", href: "/support" },
    { name: "Perguntas Frequentes", href: "/support#faq" },
    { name: "Fale Conosco", href: "/support#contato" },
    { name: "Política de Privacidade", href: "/support#privacidade" },
    { name: "Termos de Uso", href: "/support#termos" },
  ],
};

const socialLinks = [
  { icon: Facebook, href: "https://facebook.com/bauducco", label: "Facebook" },
  { icon: Instagram, href: "https://instagram.com/bauducco", label: "Instagram" },
  { icon: Twitter, href: "https://twitter.com/bauducco", label: "Twitter" },
  { icon: Youtube, href: "https://youtube.com/bauducco", label: "YouTube" },
];

export function Footer() {
  return (
    <footer className="bg-card border-t">
      {/* Newsletter Section */}
      <div className="bg-primary text-primary-foreground py-12">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="text-center md:text-left">
              <h3 className="text-xl md:text-2xl font-semibold mb-2">
                Receba ofertas exclusivas
              </h3>
              <p className="text-primary-foreground/90">
                Cadastre-se e ganhe 10% de desconto na primeira compra
              </p>
            </div>
            <form className="flex w-full md:w-auto gap-2" onSubmit={(e) => e.preventDefault()}>
              <Input
                type="email"
                placeholder="Seu melhor e-mail"
                className="bg-white/10 border-white/20 text-primary-foreground placeholder:text-primary-foreground/60 w-full md:w-72"
                data-testid="input-newsletter-email"
              />
              <Button
                type="submit"
                variant="secondary"
                className="whitespace-nowrap"
                data-testid="btn-newsletter-subscribe"
              >
                Cadastrar
              </Button>
            </form>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
          {/* Brand Column */}
          <div className="col-span-2 md:col-span-4 lg:col-span-1">
            <Link href="/">
              <span className="text-2xl font-bold text-primary">Bauducco</span>
            </Link>
            <p className="mt-4 text-sm text-muted-foreground leading-relaxed">
              Adoçando momentos e criando memórias especiais desde 1952. Qualidade e tradição em cada produto.
            </p>
            <div className="flex gap-2 mt-6">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 rounded-md hover-elevate transition-colors"
                  aria-label={social.label}
                  data-testid={`link-social-${social.label.toLowerCase()}`}
                >
                  <social.icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Products Links */}
          <div>
            <h4 className="font-semibold mb-4">Produtos</h4>
            <ul className="space-y-2.5">
              {footerLinks.products.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Institutional Links */}
          <div>
            <h4 className="font-semibold mb-4">Institucional</h4>
            <ul className="space-y-2.5">
              {footerLinks.institutional.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Links */}
          <div>
            <h4 className="font-semibold mb-4">Suporte</h4>
            <ul className="space-y-2.5">
              {footerLinks.support.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div className="col-span-2 md:col-span-1">
            <h4 className="font-semibold mb-4">Contato</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3 text-sm text-muted-foreground">
                <Phone className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>0800 123 4567</span>
              </li>
              <li className="flex items-start gap-3 text-sm text-muted-foreground">
                <Mail className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>contato@bauducco.com.br</span>
              </li>
              <li className="flex items-start gap-3 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span>São Paulo, SP - Brasil</span>
              </li>
            </ul>
          </div>
        </div>

        <Separator className="my-8" />

        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Bauducco. Todos os direitos reservados.</p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <img
              src="https://placehold.co/80x30/f5f5f5/666?text=Visa"
              alt="Visa"
              className="h-6 opacity-70"
            />
            <img
              src="https://placehold.co/80x30/f5f5f5/666?text=Master"
              alt="Mastercard"
              className="h-6 opacity-70"
            />
            <img
              src="https://placehold.co/80x30/f5f5f5/666?text=Pix"
              alt="Pix"
              className="h-6 opacity-70"
            />
            <img
              src="https://placehold.co/80x30/f5f5f5/666?text=Boleto"
              alt="Boleto"
              className="h-6 opacity-70"
            />
          </div>
        </div>
      </div>
    </footer>
  );
}
