import { useState } from "react";
import { useLocation } from "wouter";
import { ShoppingCart, Zap, Minus, Plus, Heart, Share2, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { useCart } from "@/contexts/cart-context";
import { useToast } from "@/hooks/use-toast";
import { trackAddToCart, trackBeginCheckout } from "@/lib/analytics";
import type { Product, ProductVariant } from "@shared/schema";

interface BuyBoxProps {
  product: Product;
}

export function BuyBox({ product }: BuyBoxProps) {
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant>(product.variants[0]);
  const [quantity, setQuantity] = useState(1);
  const [, navigate] = useLocation();
  const { addItem } = useCart();
  const { toast } = useToast();

  const hasDiscount = selectedVariant.compareAtPrice && selectedVariant.compareAtPrice > selectedVariant.price;
  const discountPercent = hasDiscount
    ? Math.round((1 - selectedVariant.price / selectedVariant.compareAtPrice!) * 100)
    : 0;

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price);
  };

  const handleQuantityChange = (delta: number) => {
    const newQuantity = quantity + delta;
    if (newQuantity >= 1 && newQuantity <= selectedVariant.inventory) {
      setQuantity(newQuantity);
    }
  };

  const handleAddToCart = () => {
    addItem({
      sku: selectedVariant.sku,
      productId: product.id,
      name: product.name,
      image: product.images[0] || "https://placehold.co/300x300/fef3c7/92400e?text=Produto",
      variant: selectedVariant.name,
      price: selectedVariant.price,
      compareAtPrice: selectedVariant.compareAtPrice,
      quantity,
    });

    toast({
      title: "Adicionado ao carrinho",
      description: `${quantity}x ${product.name} - ${selectedVariant.name}`,
    });
  };

  const handleBuyNow = () => {
    addItem({
      sku: selectedVariant.sku,
      productId: product.id,
      name: product.name,
      image: product.images[0] || "https://placehold.co/300x300/fef3c7/92400e?text=Produto",
      variant: selectedVariant.name,
      price: selectedVariant.price,
      compareAtPrice: selectedVariant.compareAtPrice,
      quantity,
    });
    
    trackBeginCheckout(selectedVariant.price * quantity);
    navigate("/checkout");
  };

  const isOutOfStock = product.availability === "out_of_stock" || selectedVariant.inventory === 0;

  return (
    <div className="space-y-6">
      {/* Categories */}
      {product.categories.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {product.categories.map((category) => (
            <Badge key={category} variant="secondary" className="text-xs uppercase">
              {category}
            </Badge>
          ))}
        </div>
      )}

      {/* Title */}
      <h1 className="text-2xl md:text-3xl font-semibold leading-tight" data-testid="product-title">
        {product.name}
      </h1>

      {/* Short Description */}
      <p className="text-muted-foreground">{product.shortDescription}</p>

      {/* Price */}
      <div className="space-y-1" data-testid="product-price">
        {hasDiscount && (
          <div className="flex items-center gap-2">
            <span className="text-lg text-muted-foreground line-through">
              {formatPrice(selectedVariant.compareAtPrice!)}
            </span>
            <Badge className="bg-destructive text-destructive-foreground">
              -{discountPercent}%
            </Badge>
          </div>
        )}
        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-bold text-primary">
            {formatPrice(selectedVariant.price)}
          </span>
          <span className="text-sm text-muted-foreground">à vista no PIX</span>
        </div>
        <p className="text-sm text-muted-foreground">
          ou 3x de {formatPrice(selectedVariant.price / 3)} sem juros no cartão
        </p>
      </div>

      <Separator />

      {/* Variants */}
      {product.variants.length > 1 && (
        <div className="space-y-3" data-testid="product-variants">
          <Label className="text-sm font-medium">Escolha o tamanho:</Label>
          <RadioGroup
            value={selectedVariant.sku}
            onValueChange={(sku) => {
              const variant = product.variants.find((v) => v.sku === sku);
              if (variant) {
                setSelectedVariant(variant);
                setQuantity(1);
              }
            }}
            className="flex flex-wrap gap-2"
          >
            {product.variants.map((variant) => (
              <div key={variant.sku}>
                <RadioGroupItem
                  value={variant.sku}
                  id={variant.sku}
                  className="peer sr-only"
                  disabled={variant.inventory === 0}
                />
                <Label
                  htmlFor={variant.sku}
                  className={`flex items-center justify-center px-4 py-2 border rounded-md cursor-pointer transition-all peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5 hover-elevate ${
                    variant.inventory === 0 ? "opacity-50 cursor-not-allowed" : ""
                  }`}
                >
                  <span className="font-medium">{variant.name}</span>
                  {variant.inventory <= 5 && variant.inventory > 0 && (
                    <Badge variant="secondary" className="ml-2 text-xs">
                      Últimas unidades
                    </Badge>
                  )}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </div>
      )}

      {/* Quantity */}
      <div className="space-y-3" data-testid="product-quantity">
        <Label className="text-sm font-medium">Quantidade:</Label>
        <div className="flex items-center gap-4">
          <div className="flex items-center border rounded-md">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleQuantityChange(-1)}
              disabled={quantity <= 1}
              aria-label="Diminuir quantidade"
            >
              <Minus className="h-4 w-4" />
            </Button>
            <span className="w-12 text-center font-medium">{quantity}</span>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleQuantityChange(1)}
              disabled={quantity >= selectedVariant.inventory}
              aria-label="Aumentar quantidade"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <span className="text-sm text-muted-foreground">
            {selectedVariant.inventory} disponíveis
          </span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Button
          size="lg"
          className="flex-1 gap-2"
          onClick={handleAddToCart}
          disabled={isOutOfStock}
          data-testid="btn-add-to-cart"
        >
          <ShoppingCart className="h-5 w-5" />
          Adicionar ao carrinho
        </Button>
        <Button
          size="lg"
          variant="secondary"
          className="flex-1 gap-2"
          onClick={handleBuyNow}
          disabled={isOutOfStock}
          data-testid="btn-buy-now"
        >
          <Zap className="h-5 w-5" />
          Comprar agora
        </Button>
      </div>

      {isOutOfStock && (
        <p className="text-center text-destructive font-medium">
          Produto indisponível no momento
        </p>
      )}

      {/* Secondary Actions */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" className="gap-2">
          <Heart className="h-4 w-4" />
          Favoritar
        </Button>
        <Button variant="ghost" size="sm" className="gap-2">
          <Share2 className="h-4 w-4" />
          Compartilhar
        </Button>
      </div>

      <Separator />

      {/* Shipping Info */}
      <div className="flex items-start gap-3 p-4 rounded-lg bg-accent/50">
        <Truck className="h-5 w-5 text-primary mt-0.5" />
        <div>
          <p className="font-medium text-sm">Frete grátis</p>
          <p className="text-sm text-muted-foreground">
            Em compras acima de R$ 150,00 para todo o Brasil
          </p>
        </div>
      </div>
    </div>
  );
}
