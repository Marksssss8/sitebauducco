import { useState } from "react";
import { Link } from "wouter";
import { X, Minus, Plus, Trash2, Tag, ShoppingBag, ArrowRight } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useCart } from "@/contexts/cart-context";
import { useToast } from "@/hooks/use-toast";

export function CartDrawer() {
  const { cart, isCartOpen, setIsCartOpen, removeItem, updateQuantity, applyPromoCode, removePromoCode } = useCart();
  const [promoCode, setPromoCode] = useState("");
  const [isApplyingPromo, setIsApplyingPromo] = useState(false);
  const { toast } = useToast();

  const handleApplyPromo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoCode.trim()) return;

    setIsApplyingPromo(true);
    const result = await applyPromoCode(promoCode);
    setIsApplyingPromo(false);

    if (result.success) {
      toast({
        title: "Cupom aplicado!",
        description: result.message,
      });
      setPromoCode("");
    } else {
      toast({
        title: "Erro ao aplicar cupom",
        description: result.message,
        variant: "destructive",
      });
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price);
  };

  return (
    <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
      <SheetContent className="w-full sm:max-w-lg flex flex-col p-0">
        <SheetHeader className="px-6 py-4 border-b">
          <SheetTitle className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5" />
            Carrinho
            {cart.items.length > 0 && (
              <Badge variant="secondary" className="ml-2">
                {cart.items.reduce((sum, item) => sum + item.quantity, 0)} itens
              </Badge>
            )}
          </SheetTitle>
        </SheetHeader>

        {cart.items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center px-6 py-12">
            <ShoppingBag className="h-16 w-16 text-muted-foreground/50 mb-4" />
            <h3 className="text-lg font-medium mb-2">Carrinho vazio</h3>
            <p className="text-sm text-muted-foreground text-center mb-6">
              Adicione produtos deliciosos ao seu carrinho
            </p>
            <Button onClick={() => setIsCartOpen(false)} asChild>
              <Link href="/products">Explorar produtos</Link>
            </Button>
          </div>
        ) : (
          <>
            <ScrollArea className="flex-1 px-6">
              <div className="py-4 space-y-4">
                {cart.items.map((item) => (
                  <div
                    key={item.sku}
                    className="flex gap-4 p-3 rounded-lg bg-card"
                    data-testid={`cart-item-${item.sku}`}
                  >
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-20 h-20 object-cover rounded-md"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-sm leading-tight line-clamp-2">
                        {item.name}
                      </h4>
                      <p className="text-xs text-muted-foreground mt-1">
                        {item.variant}
                      </p>
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center border rounded-md">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => updateQuantity(item.sku, item.quantity - 1)}
                            data-testid={`btn-decrease-${item.sku}`}
                            aria-label="Diminuir quantidade"
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-8 text-center text-sm" data-testid={`quantity-${item.sku}`}>
                            {item.quantity}
                          </span>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => updateQuantity(item.sku, item.quantity + 1)}
                            data-testid={`btn-increase-${item.sku}`}
                            aria-label="Aumentar quantidade"
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                        <div className="text-right">
                          {item.compareAtPrice && item.compareAtPrice > item.price && (
                            <span className="text-xs text-muted-foreground line-through block">
                              {formatPrice(item.compareAtPrice * item.quantity)}
                            </span>
                          )}
                          <span className="font-semibold text-sm">
                            {formatPrice(item.price * item.quantity)}
                          </span>
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-destructive"
                      onClick={() => removeItem(item.sku)}
                      data-testid={`btn-remove-${item.sku}`}
                      aria-label="Remover item"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </ScrollArea>

            <div className="border-t px-6 py-4 space-y-4">
              {/* Promo Code */}
              <form onSubmit={handleApplyPromo} className="flex gap-2">
                <div className="relative flex-1">
                  <Tag className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="text"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    placeholder="Cupom de desconto"
                    className="pl-9"
                    data-testid="promo-code-input"
                  />
                </div>
                <Button
                  type="submit"
                  variant="secondary"
                  disabled={isApplyingPromo || !promoCode.trim()}
                  data-testid="btn-apply-promo"
                >
                  Aplicar
                </Button>
              </form>

              {/* Applied Promos */}
              {cart.appliedPromos.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {cart.appliedPromos.map((code) => (
                    <Badge key={code} variant="secondary" className="gap-1">
                      <Tag className="h-3 w-3" />
                      {code}
                      <button
                        onClick={() => removePromoCode(code)}
                        className="ml-1 hover:text-destructive"
                        aria-label="Remover cupom"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}

              <Separator />

              {/* Totals */}
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>{formatPrice(cart.totals.subtotal)}</span>
                </div>
                {cart.totals.discount > 0 && (
                  <div className="flex justify-between text-green-600 dark:text-green-400">
                    <span>Desconto</span>
                    <span>-{formatPrice(cart.totals.discount)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Frete</span>
                  <span>
                    {cart.totals.shipping === 0 ? (
                      <span className="text-green-600 dark:text-green-400">Grátis</span>
                    ) : (
                      formatPrice(cart.totals.shipping)
                    )}
                  </span>
                </div>
                <Separator />
                <div className="flex justify-between text-lg font-semibold">
                  <span>Total</span>
                  <span>{formatPrice(cart.totals.total)}</span>
                </div>
              </div>

              {cart.totals.subtotal < 150 && (
                <p className="text-xs text-muted-foreground text-center">
                  Faltam {formatPrice(150 - cart.totals.subtotal)} para frete grátis!
                </p>
              )}

              {/* Checkout Button */}
              <Button
                className="w-full gap-2"
                size="lg"
                onClick={() => setIsCartOpen(false)}
                asChild
                data-testid="btn-go-to-checkout"
              >
                <Link href="/checkout">
                  Finalizar compra
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>

              <Button
                variant="ghost"
                className="w-full"
                onClick={() => setIsCartOpen(false)}
              >
                Continuar comprando
              </Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
