import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Menu, Search, ShoppingCart, User, ChevronDown, Sun, Moon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { useCart } from "@/contexts/cart-context";
import { useTheme } from "@/contexts/theme-context";
import { SearchBar } from "./search-bar";
import { CartDrawer } from "./cart-drawer";

const categories = [
  {
    name: "Panettones",
    href: "/products?category=panettones",
    description: "Nossos tradicionais panettones para momentos especiais",
    items: [
      { name: "Panettone Tradicional", href: "/products?category=panettones&tag=tradicional" },
      { name: "Panettone Gotas de Chocolate", href: "/products?category=panettones&tag=chocolate" },
      { name: "Panettone Frutas Cristalizadas", href: "/products?category=panettones&tag=frutas" },
      { name: "Chocottone", href: "/products?category=panettones&tag=chocottone" },
    ],
  },
  {
    name: "Biscoitos",
    href: "/products?category=biscoitos",
    description: "Biscoitos deliciosos para todos os momentos",
    items: [
      { name: "Cookies", href: "/products?category=biscoitos&tag=cookies" },
      { name: "Wafers", href: "/products?category=biscoitos&tag=wafers" },
      { name: "Amanteigados", href: "/products?category=biscoitos&tag=amanteigados" },
      { name: "Recheados", href: "/products?category=biscoitos&tag=recheados" },
    ],
  },
  {
    name: "Bolos",
    href: "/products?category=bolos",
    description: "Bolos prontos e misturas para bolo",
    items: [
      { name: "Bolo Pronto", href: "/products?category=bolos&tag=pronto" },
      { name: "Mistura para Bolo", href: "/products?category=bolos&tag=mistura" },
    ],
  },
  {
    name: "Torradas",
    href: "/products?category=torradas",
    description: "Torradas crocantes para seu café da manhã",
    items: [
      { name: "Torrada Tradicional", href: "/products?category=torradas&tag=tradicional" },
      { name: "Torrada Integral", href: "/products?category=torradas&tag=integral" },
    ],
  },
];

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [location] = useLocation();
  const { itemCount, setIsCartOpen } = useCart();
  const { theme, toggleTheme } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
    setIsSearchOpen(false);
  }, [location]);

  return (
    <>
      {/* Top Banner */}
      <div className="bg-primary text-primary-foreground text-center py-2 px-4 text-sm font-medium">
        <span className="hidden sm:inline">Frete grátis em compras acima de R$ 150 | </span>
        <span>Use o cupom PRIMEIRA10 e ganhe 10% OFF</span>
      </div>

      {/* Main Header */}
      <header
        className={`sticky top-0 z-50 w-full transition-all duration-300 ${
          isScrolled
            ? "bg-background/95 backdrop-blur-md shadow-md py-2"
            : "bg-background py-4"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex items-center justify-between gap-4">
            {/* Mobile Menu Button */}
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="lg:hidden"
                  data-testid="btn-open-main-menu"
                  aria-label="Menu"
                >
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[300px] sm:w-[350px] p-0">
                <div className="flex flex-col h-full">
                  <div className="p-4 border-b">
                    <Link href="/" onClick={() => setIsMobileMenuOpen(false)}>
                      <span className="text-2xl font-bold text-primary">Bauducco</span>
                    </Link>
                  </div>
                  <nav className="flex-1 overflow-y-auto p-4">
                    <div className="space-y-2">
                      {categories.map((category) => (
                        <div key={category.name} className="space-y-1">
                          <Link
                            href={category.href}
                            onClick={() => setIsMobileMenuOpen(false)}
                            className="flex items-center justify-between py-2 px-3 rounded-md font-medium hover-elevate"
                          >
                            {category.name}
                            <ChevronDown className="h-4 w-4" />
                          </Link>
                          <div className="pl-4 space-y-1">
                            {category.items.map((item) => (
                              <Link
                                key={item.name}
                                href={item.href}
                                onClick={() => setIsMobileMenuOpen(false)}
                                className="block py-1.5 px-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
                              >
                                {item.name}
                              </Link>
                            ))}
                          </div>
                        </div>
                      ))}
                      <div className="pt-4 border-t mt-4 space-y-1">
                        <Link
                          href="/blog/recipes"
                          onClick={() => setIsMobileMenuOpen(false)}
                          className="block py-2 px-3 rounded-md font-medium hover-elevate"
                        >
                          Receitas
                        </Link>
                        <Link
                          href="/about"
                          onClick={() => setIsMobileMenuOpen(false)}
                          className="block py-2 px-3 rounded-md font-medium hover-elevate"
                        >
                          Nossa História
                        </Link>
                        <Link
                          href="/support"
                          onClick={() => setIsMobileMenuOpen(false)}
                          className="block py-2 px-3 rounded-md font-medium hover-elevate"
                        >
                          Suporte
                        </Link>
                      </div>
                    </div>
                  </nav>
                </div>
              </SheetContent>
            </Sheet>

            {/* Logo */}
            <Link href="/" className="flex-shrink-0">
              <span className="text-2xl md:text-3xl font-bold text-primary tracking-tight">
                Bauducco
              </span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-1">
              {categories.map((category) => (
                <div key={category.name} className="relative group">
                  <button
                    className="inline-flex items-center h-10 px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground rounded-md focus:outline-none"
                  >
                    {category.name}
                    <ChevronDown className="ml-1 h-3 w-3 transition-transform group-hover:rotate-180" />
                  </button>
                  <div className="absolute left-0 top-full pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                    <div className="bg-popover border rounded-md shadow-lg p-6 w-[400px]">
                      <div className="mb-4">
                        <Link
                          href={category.href}
                          className="text-lg font-semibold hover:text-primary transition-colors"
                        >
                          {category.name}
                        </Link>
                        <p className="text-sm text-muted-foreground mt-1">
                          {category.description}
                        </p>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        {category.items.map((item) => (
                          <Link
                            key={item.name}
                            href={item.href}
                            className="block p-3 rounded-md hover-elevate transition-all"
                          >
                            <span className="text-sm font-medium">{item.name}</span>
                          </Link>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              <Link
                href="/blog/recipes"
                className="inline-flex h-10 items-center px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground rounded-md"
              >
                Receitas
              </Link>
              <Link
                href="/about"
                className="inline-flex h-10 items-center px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground rounded-md"
              >
                Nossa História
              </Link>
            </nav>

            {/* Right Actions */}
            <div className="flex items-center gap-1">
              {/* Search - Desktop */}
              <div className="hidden md:block">
                <SearchBar />
              </div>

              {/* Search - Mobile */}
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                onClick={() => setIsSearchOpen(!isSearchOpen)}
                data-testid="btn-search-mobile"
                aria-label="Buscar"
              >
                <Search className="h-5 w-5" />
              </Button>

              {/* Theme Toggle */}
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                data-testid="btn-theme-toggle"
                aria-label={theme === "light" ? "Modo escuro" : "Modo claro"}
              >
                {theme === "light" ? (
                  <Moon className="h-5 w-5" />
                ) : (
                  <Sun className="h-5 w-5" />
                )}
              </Button>

              {/* Account */}
              <Button
                variant="ghost"
                size="icon"
                asChild
                data-testid="btn-account"
                aria-label="Minha conta"
              >
                <Link href="/my-account">
                  <User className="h-5 w-5" />
                </Link>
              </Button>

              {/* Cart */}
              <Button
                variant="ghost"
                size="icon"
                className="relative"
                onClick={() => setIsCartOpen(true)}
                data-testid="btn-cart"
                aria-label="Carrinho"
              >
                <ShoppingCart className="h-5 w-5" />
                {itemCount > 0 && (
                  <Badge
                    className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
                    data-testid="badge-cart-count"
                  >
                    {itemCount > 99 ? "99+" : itemCount}
                  </Badge>
                )}
              </Button>
            </div>
          </div>

          {/* Mobile Search Bar */}
          {isSearchOpen && (
            <div className="md:hidden mt-4 pb-2">
              <SearchBar autoFocus onClose={() => setIsSearchOpen(false)} />
            </div>
          )}
        </div>
      </header>

      {/* Cart Drawer */}
      <CartDrawer />
    </>
  );
}
