import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, Calendar, Clock, Gift } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { PromoBanner } from "@/components/promo-banner";
import { ProductCard } from "@/components/product-card";
import type { PromoPage, Product } from "@shared/schema";
import { Link } from "wouter";

export default function Promo() {
  const { campaign } = useParams<{ campaign: string }>();

  const { data: promoPage, isLoading, error } = useQuery<PromoPage>({
    queryKey: ["/api/promo", campaign],
  });

  const { data: promoProducts } = useQuery<Product[]>({
    queryKey: ["/api/products", { promo: campaign, limit: 8 }],
    enabled: !!promoPage,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Skeleton className="h-[500px] w-full" />
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-12">
          <Skeleton className="h-10 w-1/2 mx-auto mb-4" />
          <Skeleton className="h-6 w-3/4 mx-auto mb-12" />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i}>
                <Skeleton className="aspect-[4/3]" />
                <CardContent className="p-4 space-y-3">
                  <Skeleton className="h-5 w-full" />
                  <Skeleton className="h-6 w-24" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Default promo page if API doesn't return one
  const defaultPromo: PromoPage = {
    id: "natal-2024",
    campaign: "natal",
    title: "Natal Bauducco",
    subtitle: "Os melhores panettones e chocottones para sua celebração",
    heroImage: "https://images.unsplash.com/photo-1512389142860-9c449e58a814?w=1920&q=80",
    heroCtaText: "Ver ofertas",
    heroCtaLink: "/products?tag=natal",
    sections: [],
    startDate: "2024-11-01",
    endDate: "2024-12-31",
    active: true,
  };

  const page = promoPage || defaultPromo;

  // Calculate countdown
  const endDate = new Date(page.endDate);
  const now = new Date();
  const daysRemaining = Math.max(0, Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <PromoBanner
        title={page.title}
        subtitle={page.subtitle}
        ctaText={page.heroCtaText}
        ctaLink={page.heroCtaLink}
        backgroundImage={page.heroImage}
        variant="hero"
        align="center"
      />

      {/* Countdown Badge */}
      {daysRemaining > 0 && daysRemaining <= 30 && (
        <div className="bg-primary text-primary-foreground py-3">
          <div className="max-w-7xl mx-auto px-4 md:px-8 flex items-center justify-center gap-4">
            <Clock className="h-5 w-5" />
            <span className="font-medium">
              {daysRemaining === 1 
                ? "Último dia de promoção!" 
                : `Faltam ${daysRemaining} dias para o fim da promoção!`}
            </span>
          </div>
        </div>
      )}

      {/* Featured Products */}
      <section className="py-12 md:py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="text-center mb-12">
            <Badge className="mb-4" variant="secondary">
              <Gift className="h-3 w-3 mr-1" />
              Ofertas Especiais
            </Badge>
            <h2 className="text-2xl md:text-3xl font-semibold mb-4">
              Produtos em Promoção
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Aproveite os melhores preços em produtos selecionados para esta temporada
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {(promoProducts || []).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <div className="text-center mt-8">
            <Button asChild size="lg">
              <Link href={`/products?tag=${campaign}`}>
                Ver todos os produtos
                <ArrowRight className="h-4 w-4 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-12 md:py-16 bg-accent/30">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <h2 className="text-2xl font-semibold text-center mb-8">
            Por que comprar na Bauducco?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 mb-4">
                  <Gift className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Produtos Frescos</h3>
                <p className="text-sm text-muted-foreground">
                  Garantia de qualidade e frescor em todos os produtos
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 mb-4">
                  <Calendar className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Entrega Garantida</h3>
                <p className="text-sm text-muted-foreground">
                  Receba seu pedido a tempo para suas celebrações
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 mb-4">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">Tradição desde 1952</h3>
                <p className="text-sm text-muted-foreground">
                  Mais de 70 anos de história e qualidade
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Secondary CTA */}
      <PromoBanner
        title="Não perca essa oportunidade!"
        subtitle="Use o cupom NATAL15 e ganhe 15% de desconto adicional"
        ctaText="Comprar agora"
        ctaLink="/products"
        backgroundImage="https://images.unsplash.com/photo-1481391319762-47dff72954d9?w=1920&q=80"
        variant="section"
        align="left"
      />
    </div>
  );
}
