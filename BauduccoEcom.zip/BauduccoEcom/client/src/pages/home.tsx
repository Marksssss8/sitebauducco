import { Link } from "wouter";
import { ArrowRight, Star, ChefHat, Gift, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ProductCard } from "@/components/product-card";
import { RecipeCard } from "@/components/recipe-card";
import { PromoBanner } from "@/components/promo-banner";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import type { Product, Recipe } from "@shared/schema";

export default function Home() {
  const { data: featuredProducts, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ["/api/products", { featured: true, limit: 4 }],
  });

  const { data: featuredRecipes, isLoading: isLoadingRecipes } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes", { featured: true, limit: 3 }],
  });

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <PromoBanner
        title="Adoce seus momentos especiais"
        subtitle="Descubra nossa linha completa de panettones, biscoitos e muito mais para celebrar com quem você ama."
        ctaText="Explorar produtos"
        ctaLink="/products"
        backgroundImage="https://images.unsplash.com/photo-1481391319762-47dff72954d9?w=1920&q=80"
        variant="hero"
        align="left"
      />

      {/* Features Bar */}
      <section className="bg-card border-y py-6">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-center gap-4 justify-center md:justify-start">
              <div className="p-3 rounded-full bg-primary/10">
                <Truck className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-medium">Frete Grátis</p>
                <p className="text-sm text-muted-foreground">Acima de R$ 150</p>
              </div>
            </div>
            <div className="flex items-center gap-4 justify-center">
              <div className="p-3 rounded-full bg-primary/10">
                <Gift className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-medium">10% OFF</p>
                <p className="text-sm text-muted-foreground">Na primeira compra</p>
              </div>
            </div>
            <div className="flex items-center gap-4 justify-center md:justify-end">
              <div className="p-3 rounded-full bg-primary/10">
                <Star className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-medium">Qualidade Premium</p>
                <p className="text-sm text-muted-foreground">Desde 1952</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-12 md:py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-semibold mb-2">
                Produtos em Destaque
              </h2>
              <p className="text-muted-foreground">
                Os favoritos dos nossos clientes
              </p>
            </div>
            <Button variant="ghost" asChild className="hidden md:flex">
              <Link href="/products">
                Ver todos
                <ArrowRight className="h-4 w-4 ml-2" />
              </Link>
            </Button>
          </div>

          {isLoadingProducts ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              {[1, 2, 3, 4].map((i) => (
                <Card key={i}>
                  <Skeleton className="aspect-[4/3] rounded-t-md" />
                  <CardContent className="p-4 space-y-3">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-5 w-full" />
                    <Skeleton className="h-6 w-24" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              {(featuredProducts || []).map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}

          <div className="mt-8 text-center md:hidden">
            <Button asChild>
              <Link href="/products">
                Ver todos os produtos
                <ArrowRight className="h-4 w-4 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-12 md:py-16 bg-accent/30">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <h2 className="text-2xl md:text-3xl font-semibold text-center mb-8">
            Explore por Categoria
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {[
              { name: "Panettones", image: "https://images.unsplash.com/photo-1574085733277-851d9d856a3a?w=400&h=300&fit=crop", href: "/products?category=panettones" },
              { name: "Biscoitos", image: "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&h=300&fit=crop", href: "/products?category=biscoitos" },
              { name: "Bolos", image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=300&fit=crop", href: "/products?category=bolos" },
              { name: "Torradas", image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&h=300&fit=crop", href: "/products?category=torradas" },
            ].map((category) => (
              <Link key={category.name} href={category.href}>
                <Card className="group overflow-visible hover-elevate transition-all duration-300">
                  <div className="relative aspect-[4/3] overflow-hidden rounded-t-md">
                    <img
                      src={category.image}
                      alt={category.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <h3 className="absolute bottom-4 left-4 text-xl font-semibold text-white">
                      {category.name}
                    </h3>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Seasonal Promo Banner */}
      <PromoBanner
        title="Promoção de Natal"
        subtitle="Até 30% de desconto em panettones selecionados. Aproveite!"
        ctaText="Ver ofertas"
        ctaLink="/promo/natal"
        backgroundImage="https://images.unsplash.com/photo-1512389142860-9c449e58a814?w=1920&q=80"
        variant="section"
        align="center"
      />

      {/* Recipes Section */}
      <section className="py-12 md:py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <div className="flex items-center gap-2 text-primary mb-2">
                <ChefHat className="h-5 w-5" />
                <span className="text-sm font-medium uppercase tracking-wide">Receitas</span>
              </div>
              <h2 className="text-2xl md:text-3xl font-semibold mb-2">
                Inspire-se com nossas receitas
              </h2>
              <p className="text-muted-foreground">
                Delícias para fazer em casa
              </p>
            </div>
            <Button variant="ghost" asChild className="hidden md:flex">
              <Link href="/blog/recipes">
                Ver todas
                <ArrowRight className="h-4 w-4 ml-2" />
              </Link>
            </Button>
          </div>

          {isLoadingRecipes ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {[1, 2, 3].map((i) => (
                <Card key={i}>
                  <Skeleton className="aspect-video rounded-t-md" />
                  <CardContent className="p-4 space-y-3">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-6 w-full" />
                    <Skeleton className="h-4 w-3/4" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {(featuredRecipes || []).map((recipe) => (
                <RecipeCard key={recipe.id} recipe={recipe} />
              ))}
            </div>
          )}

          <div className="mt-8 text-center md:hidden">
            <Button asChild>
              <Link href="/blog/recipes">
                Ver todas as receitas
                <ArrowRight className="h-4 w-4 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* About Teaser */}
      <section className="py-12 md:py-16 bg-card">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
            <div>
              <h2 className="text-2xl md:text-3xl font-semibold mb-4">
                Uma tradição de mais de 70 anos
              </h2>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                Desde 1952, a Bauducco está presente nos momentos mais especiais das famílias brasileiras. Nossa história é feita de qualidade, tradição e muito carinho em cada produto.
              </p>
              <Button variant="outline" asChild>
                <Link href="/about">
                  Conheça nossa história
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Link>
              </Button>
            </div>
            <div className="relative aspect-video rounded-lg overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800&h=600&fit=crop"
                alt="Tradição Bauducco"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
