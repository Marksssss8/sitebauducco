import { Link } from "wouter";
import { Home, ArrowLeft, Search } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center py-16">
      <div className="max-w-md mx-auto px-4 text-center">
        <div className="text-8xl font-bold text-primary mb-4">404</div>
        <h1 className="text-2xl font-semibold mb-4">Página não encontrada</h1>
        <p className="text-muted-foreground mb-8">
          Ops! A página que você está procurando não existe ou foi movida.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button asChild>
            <Link href="/">
              <Home className="h-4 w-4 mr-2" />
              Ir para o início
            </Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/products">
              <Search className="h-4 w-4 mr-2" />
              Buscar produtos
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
