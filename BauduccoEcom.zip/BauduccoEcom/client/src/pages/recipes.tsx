import { useState } from "react";
import { ChefHat, Clock, Filter, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { RecipeCard } from "@/components/recipe-card";
import { useQuery } from "@tanstack/react-query";
import type { Recipe } from "@shared/schema";

const categories = [
  { id: "all", name: "Todas" },
  { id: "sobremesas", name: "Sobremesas" },
  { id: "bolos", name: "Bolos" },
  { id: "cafe-da-manha", name: "Café da Manhã" },
  { id: "festas", name: "Festas" },
  { id: "natal", name: "Natal" },
];

const difficulties = [
  { id: "easy", name: "Fácil", color: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300" },
  { id: "medium", name: "Médio", color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300" },
  { id: "hard", name: "Difícil", color: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300" },
];

export default function Recipes() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: recipes, isLoading } = useQuery<Recipe[]>({
    queryKey: ["/api/recipes", { 
      category: selectedCategory !== "all" ? selectedCategory : undefined,
      difficulty: selectedDifficulty,
      q: searchQuery,
    }],
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // The query will update automatically via the queryKey
  };

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 text-primary mb-4">
            <ChefHat className="h-6 w-6" />
            <span className="text-sm font-medium uppercase tracking-wide">Receitas</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-semibold mb-4">
            Delícias para fazer em casa
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Descubra receitas incríveis usando nossos produtos. De sobremesas a cafés da manhã especiais, 
            temos opções para todos os momentos.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="mb-8 space-y-4">
          {/* Search Bar */}
          <form onSubmit={handleSearch} className="max-w-md mx-auto">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Buscar receitas..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="search-recipes"
              />
            </div>
          </form>

          {/* Category Filters */}
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
                data-testid={`filter-category-${category.id}`}
              >
                {category.name}
              </Button>
            ))}
          </div>

          {/* Difficulty Filters */}
          <div className="flex justify-center gap-2">
            {difficulties.map((difficulty) => (
              <Badge
                key={difficulty.id}
                variant="secondary"
                className={`cursor-pointer ${
                  selectedDifficulty === difficulty.id 
                    ? difficulty.color 
                    : "hover-elevate"
                }`}
                onClick={() => setSelectedDifficulty(
                  selectedDifficulty === difficulty.id ? null : difficulty.id
                )}
                data-testid={`filter-difficulty-${difficulty.id}`}
              >
                {difficulty.name}
              </Badge>
            ))}
          </div>
        </div>

        {/* Recipes Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i}>
                <Skeleton className="aspect-video rounded-t-md" />
                <CardContent className="p-4 space-y-3">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-6 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : recipes && recipes.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {recipes.map((recipe) => (
              <RecipeCard key={recipe.id} recipe={recipe} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <ChefHat className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
            <h2 className="text-xl font-medium mb-2">Nenhuma receita encontrada</h2>
            <p className="text-muted-foreground mb-6">
              Tente ajustar os filtros ou buscar por outro termo
            </p>
            <Button onClick={() => {
              setSelectedCategory("all");
              setSelectedDifficulty(null);
              setSearchQuery("");
            }}>
              Limpar filtros
            </Button>
          </div>
        )}

        {/* Newsletter CTA */}
        <section className="mt-16 bg-accent/30 rounded-lg p-8 text-center">
          <h2 className="text-2xl font-semibold mb-4">
            Receba novas receitas por e-mail
          </h2>
          <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
            Cadastre-se e receba receitas exclusivas, dicas e novidades diretamente no seu e-mail.
          </p>
          <form className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto" onSubmit={(e) => e.preventDefault()}>
            <Input
              type="email"
              placeholder="Seu e-mail"
              className="flex-1"
              data-testid="input-recipe-newsletter"
            />
            <Button type="submit" data-testid="btn-recipe-newsletter">
              Cadastrar
            </Button>
          </form>
        </section>
      </div>
    </div>
  );
}
