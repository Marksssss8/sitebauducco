import { useState, useEffect } from "react";
import { useLocation, useSearch } from "wouter";
import { Filter, SlidersHorizontal, X, ChevronDown, Grid3X3, LayoutList } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { ProductCard } from "@/components/product-card";
import { useQuery } from "@tanstack/react-query";
import type { Product } from "@shared/schema";

const categories = [
  { id: "panettones", name: "Panettones" },
  { id: "biscoitos", name: "Biscoitos" },
  { id: "bolos", name: "Bolos" },
  { id: "torradas", name: "Torradas" },
];

const priceRanges = [
  { id: "0-20", label: "Até R$ 20", min: 0, max: 20 },
  { id: "20-50", label: "R$ 20 - R$ 50", min: 20, max: 50 },
  { id: "50-100", label: "R$ 50 - R$ 100", min: 50, max: 100 },
  { id: "100+", label: "Acima de R$ 100", min: 100, max: 9999 },
];

const sortOptions = [
  { value: "relevance", label: "Relevância" },
  { value: "price_asc", label: "Menor preço" },
  { value: "price_desc", label: "Maior preço" },
  { value: "newest", label: "Mais recentes" },
];

export default function Products() {
  const search = useSearch();
  const [, navigate] = useLocation();
  const params = new URLSearchParams(search);

  const [selectedCategories, setSelectedCategories] = useState<string[]>(
    params.get("category")?.split(",").filter(Boolean) || []
  );
  const [selectedPriceRange, setSelectedPriceRange] = useState<string | null>(
    params.get("price") || null
  );
  const [sortBy, setSortBy] = useState(params.get("sort") || "relevance");
  const [searchQuery, setSearchQuery] = useState(params.get("q") || "");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products", { 
      category: selectedCategories.join(","),
      price: selectedPriceRange,
      sort: sortBy,
      q: searchQuery,
    }],
  });

  const updateFilters = () => {
    const newParams = new URLSearchParams();
    if (selectedCategories.length > 0) {
      newParams.set("category", selectedCategories.join(","));
    }
    if (selectedPriceRange) {
      newParams.set("price", selectedPriceRange);
    }
    if (sortBy !== "relevance") {
      newParams.set("sort", sortBy);
    }
    if (searchQuery) {
      newParams.set("q", searchQuery);
    }
    navigate(`/products?${newParams.toString()}`);
  };

  useEffect(() => {
    updateFilters();
  }, [selectedCategories, selectedPriceRange, sortBy]);

  const toggleCategory = (categoryId: string) => {
    setSelectedCategories((prev) =>
      prev.includes(categoryId)
        ? prev.filter((c) => c !== categoryId)
        : [...prev, categoryId]
    );
  };

  const clearFilters = () => {
    setSelectedCategories([]);
    setSelectedPriceRange(null);
    setSortBy("relevance");
    setSearchQuery("");
    navigate("/products");
  };

  const activeFilterCount = 
    selectedCategories.length + 
    (selectedPriceRange ? 1 : 0) + 
    (searchQuery ? 1 : 0);

  const FilterContent = () => (
    <div className="space-y-6">
      {/* Search */}
      <div>
        <Label className="text-sm font-medium mb-2 block">Buscar</Label>
        <Input
          type="search"
          placeholder="Buscar produtos..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && updateFilters()}
          data-testid="filter-search"
        />
      </div>

      <Separator />

      {/* Categories */}
      <Collapsible defaultOpen>
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2">
          <Label className="text-sm font-medium">Categorias</Label>
          <ChevronDown className="h-4 w-4" />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-2 space-y-2">
          {categories.map((category) => (
            <div key={category.id} className="flex items-center gap-2">
              <Checkbox
                id={category.id}
                checked={selectedCategories.includes(category.id)}
                onCheckedChange={() => toggleCategory(category.id)}
                data-testid={`filter-category-${category.id}`}
              />
              <Label htmlFor={category.id} className="text-sm cursor-pointer">
                {category.name}
              </Label>
            </div>
          ))}
        </CollapsibleContent>
      </Collapsible>

      <Separator />

      {/* Price Range */}
      <Collapsible defaultOpen>
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2">
          <Label className="text-sm font-medium">Preço</Label>
          <ChevronDown className="h-4 w-4" />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-2 space-y-2">
          {priceRanges.map((range) => (
            <div key={range.id} className="flex items-center gap-2">
              <Checkbox
                id={range.id}
                checked={selectedPriceRange === range.id}
                onCheckedChange={() =>
                  setSelectedPriceRange((prev) => (prev === range.id ? null : range.id))
                }
                data-testid={`filter-price-${range.id}`}
              />
              <Label htmlFor={range.id} className="text-sm cursor-pointer">
                {range.label}
              </Label>
            </div>
          ))}
        </CollapsibleContent>
      </Collapsible>

      {activeFilterCount > 0 && (
        <>
          <Separator />
          <Button
            variant="ghost"
            className="w-full"
            onClick={clearFilters}
            data-testid="btn-clear-filters"
          >
            <X className="h-4 w-4 mr-2" />
            Limpar filtros ({activeFilterCount})
          </Button>
        </>
      )}
    </div>
  );

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-semibold mb-2">Nossos Produtos</h1>
          <p className="text-muted-foreground">
            Descubra toda a nossa linha de produtos deliciosos
          </p>
        </div>

        {/* Active Filters */}
        {activeFilterCount > 0 && (
          <div className="flex flex-wrap items-center gap-2 mb-6">
            <span className="text-sm text-muted-foreground">Filtros ativos:</span>
            {selectedCategories.map((cat) => (
              <Badge key={cat} variant="secondary" className="gap-1">
                {categories.find((c) => c.id === cat)?.name}
                <button onClick={() => toggleCategory(cat)}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
            {selectedPriceRange && (
              <Badge variant="secondary" className="gap-1">
                {priceRanges.find((r) => r.id === selectedPriceRange)?.label}
                <button onClick={() => setSelectedPriceRange(null)}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            {searchQuery && (
              <Badge variant="secondary" className="gap-1">
                "{searchQuery}"
                <button onClick={() => setSearchQuery("")}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
          </div>
        )}

        <div className="flex gap-8">
          {/* Desktop Filters */}
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <div className="sticky top-24">
              <h2 className="font-semibold mb-4 flex items-center gap-2">
                <Filter className="h-4 w-4" />
                Filtros
              </h2>
              <FilterContent />
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {/* Toolbar */}
            <div className="flex items-center justify-between gap-4 mb-6">
              <div className="flex items-center gap-2">
                {/* Mobile Filter Button */}
                <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
                  <SheetTrigger asChild>
                    <Button variant="outline" className="lg:hidden" data-testid="btn-open-filters">
                      <SlidersHorizontal className="h-4 w-4 mr-2" />
                      Filtros
                      {activeFilterCount > 0 && (
                        <Badge className="ml-2">{activeFilterCount}</Badge>
                      )}
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-[300px]">
                    <SheetHeader>
                      <SheetTitle>Filtros</SheetTitle>
                    </SheetHeader>
                    <div className="mt-6">
                      <FilterContent />
                    </div>
                  </SheetContent>
                </Sheet>

                <p className="text-sm text-muted-foreground hidden sm:block">
                  {isLoading ? "Carregando..." : `${products?.length || 0} produtos encontrados`}
                </p>
              </div>

              <div className="flex items-center gap-2">
                {/* View Mode Toggle */}
                <div className="hidden sm:flex items-center border rounded-md">
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`h-9 w-9 ${viewMode === "grid" ? "bg-accent" : ""}`}
                    onClick={() => setViewMode("grid")}
                    aria-label="Visualização em grade"
                  >
                    <Grid3X3 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`h-9 w-9 ${viewMode === "list" ? "bg-accent" : ""}`}
                    onClick={() => setViewMode("list")}
                    aria-label="Visualização em lista"
                  >
                    <LayoutList className="h-4 w-4" />
                  </Button>
                </div>

                {/* Sort */}
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-40" data-testid="select-sort">
                    <SelectValue placeholder="Ordenar por" />
                  </SelectTrigger>
                  <SelectContent>
                    {sortOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Products Grid */}
            {isLoading ? (
              <div className={`grid gap-4 md:gap-6 ${
                viewMode === "grid"
                  ? "grid-cols-2 md:grid-cols-3"
                  : "grid-cols-1"
              }`}>
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <Card key={i}>
                    <Skeleton className="aspect-[4/3] rounded-t-md" />
                    <CardContent className="p-4 space-y-3">
                      <Skeleton className="h-4 w-20" />
                      <Skeleton className="h-5 w-full" />
                      <Skeleton className="h-6 w-24" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : products && products.length > 0 ? (
              <div className={`grid gap-4 md:gap-6 ${
                viewMode === "grid"
                  ? "grid-cols-2 md:grid-cols-3"
                  : "grid-cols-1"
              }`}>
                {products.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <p className="text-xl font-medium mb-2">Nenhum produto encontrado</p>
                <p className="text-muted-foreground mb-6">
                  Tente ajustar seus filtros ou buscar por outro termo
                </p>
                <Button onClick={clearFilters}>Limpar filtros</Button>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
