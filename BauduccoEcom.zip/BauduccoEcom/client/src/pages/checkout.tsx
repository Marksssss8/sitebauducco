import { useState } from "react";
import { useLocation, Link } from "wouter";
import { ArrowLeft, ArrowRight, CreditCard, QrCode, Barcode, Check, Loader2, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { CheckoutSteps } from "@/components/checkout-steps";
import { AddressForm } from "@/components/address-form";
import { ShippingCalculator } from "@/components/shipping-calculator";
import { useCart } from "@/contexts/cart-context";
import { useToast } from "@/hooks/use-toast";
import { trackAddShippingInfo, trackAddPaymentInfo, trackPurchase } from "@/lib/analytics";
import type { Address, ShippingOption, PaymentMethod } from "@shared/schema";

type CheckoutStep = 1 | 2 | 3 | 4;

export default function Checkout() {
  const [currentStep, setCurrentStep] = useState<CheckoutStep>(1);
  const [address, setAddress] = useState<Address | null>(null);
  const [shippingOption, setShippingOption] = useState<ShippingOption | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod["type"]>("credit_card");
  const [isProcessing, setIsProcessing] = useState(false);
  const [, navigate] = useLocation();
  const { cart, clearCart } = useCart();
  const { toast } = useToast();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price);
  };

  if (cart.items.length === 0) {
    return (
      <div className="min-h-screen py-16">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="text-center max-w-md mx-auto">
            <ShoppingBag className="h-24 w-24 text-muted-foreground/30 mx-auto mb-6" />
            <h1 className="text-2xl font-semibold mb-4">Seu carrinho está vazio</h1>
            <p className="text-muted-foreground mb-8">
              Adicione produtos ao carrinho antes de finalizar a compra.
            </p>
            <Button asChild size="lg">
              <Link href="/products">Explorar produtos</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const handleAddressSubmit = (data: Address) => {
    setAddress(data);
    setCurrentStep(2);
  };

  const handleShippingSelect = (option: ShippingOption) => {
    setShippingOption(option);
    trackAddShippingInfo(option.name);
  };

  const handleShippingContinue = () => {
    if (shippingOption) {
      setCurrentStep(3);
    }
  };

  const handlePaymentContinue = () => {
    trackAddPaymentInfo(paymentMethod);
    setCurrentStep(4);
  };

  const handlePlaceOrder = async () => {
    setIsProcessing(true);

    try {
      // Simulate order processing
      await new Promise((resolve) => setTimeout(resolve, 2000));

      const orderId = `ORD-${Date.now()}`;
      trackPurchase(orderId, cart.totals.total);

      clearCart();

      toast({
        title: "Pedido realizado com sucesso!",
        description: `Seu pedido #${orderId} foi confirmado.`,
      });

      navigate(`/my-account?order=${orderId}`);
    } catch (error) {
      toast({
        title: "Erro ao processar pedido",
        description: "Por favor, tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const goBack = () => {
    if (currentStep > 1) {
      setCurrentStep((prev) => (prev - 1) as CheckoutStep);
    }
  };

  const totalWithShipping = cart.totals.total - cart.totals.shipping + (shippingOption?.price || cart.totals.shipping);

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-4xl mx-auto px-4 md:px-8">
        <h1 className="text-3xl font-semibold mb-8">Checkout</h1>

        <CheckoutSteps currentStep={currentStep} />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Step 1: Address */}
            {currentStep === 1 && (
              <Card>
                <CardHeader>
                  <CardTitle>Endereço de Entrega</CardTitle>
                </CardHeader>
                <CardContent>
                  <AddressForm initialData={address || undefined} onSubmit={handleAddressSubmit} />
                </CardContent>
              </Card>
            )}

            {/* Step 2: Shipping */}
            {currentStep === 2 && (
              <Card>
                <CardHeader>
                  <CardTitle>Opções de Entrega</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="p-4 bg-accent/50 rounded-lg">
                    <p className="text-sm font-medium mb-1">Entregar para:</p>
                    <p className="text-sm text-muted-foreground">
                      {address?.name} - {address?.street}, {address?.number}
                      {address?.complement && `, ${address.complement}`}
                      <br />
                      {address?.neighborhood}, {address?.city} - {address?.state}
                      <br />
                      CEP: {address?.zipCode}
                    </p>
                  </div>

                  <ShippingCalculator
                    onSelectShipping={handleShippingSelect}
                    selectedOptionId={shippingOption?.id}
                  />

                  <div className="flex justify-between pt-4">
                    <Button variant="ghost" onClick={goBack}>
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Voltar
                    </Button>
                    <Button onClick={handleShippingContinue} disabled={!shippingOption}>
                      Continuar
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step 3: Payment */}
            {currentStep === 3 && (
              <Card>
                <CardHeader>
                  <CardTitle>Forma de Pagamento</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <RadioGroup
                    value={paymentMethod}
                    onValueChange={(value) => setPaymentMethod(value as PaymentMethod["type"])}
                    className="space-y-3"
                  >
                    <Card
                      className={`cursor-pointer transition-all ${
                        paymentMethod === "credit_card" ? "border-primary ring-2 ring-primary/20" : "hover-elevate"
                      }`}
                      onClick={() => setPaymentMethod("credit_card")}
                    >
                      <CardContent className="p-4 flex items-center gap-3">
                        <RadioGroupItem value="credit_card" id="credit_card" />
                        <CreditCard className="h-5 w-5 text-muted-foreground" />
                        <div className="flex-1">
                          <Label htmlFor="credit_card" className="font-medium cursor-pointer">
                            Cartão de Crédito
                          </Label>
                          <p className="text-sm text-muted-foreground">Até 3x sem juros</p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card
                      className={`cursor-pointer transition-all ${
                        paymentMethod === "pix" ? "border-primary ring-2 ring-primary/20" : "hover-elevate"
                      }`}
                      onClick={() => setPaymentMethod("pix")}
                    >
                      <CardContent className="p-4 flex items-center gap-3">
                        <RadioGroupItem value="pix" id="pix" />
                        <QrCode className="h-5 w-5 text-muted-foreground" />
                        <div className="flex-1">
                          <Label htmlFor="pix" className="font-medium cursor-pointer">
                            PIX
                          </Label>
                          <p className="text-sm text-muted-foreground">Aprovação instantânea</p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card
                      className={`cursor-pointer transition-all ${
                        paymentMethod === "boleto" ? "border-primary ring-2 ring-primary/20" : "hover-elevate"
                      }`}
                      onClick={() => setPaymentMethod("boleto")}
                    >
                      <CardContent className="p-4 flex items-center gap-3">
                        <RadioGroupItem value="boleto" id="boleto" />
                        <Barcode className="h-5 w-5 text-muted-foreground" />
                        <div className="flex-1">
                          <Label htmlFor="boleto" className="font-medium cursor-pointer">
                            Boleto Bancário
                          </Label>
                          <p className="text-sm text-muted-foreground">Vencimento em 3 dias úteis</p>
                        </div>
                      </CardContent>
                    </Card>
                  </RadioGroup>

                  {paymentMethod === "credit_card" && (
                    <div className="space-y-4 p-4 bg-accent/50 rounded-lg">
                      <div>
                        <Label htmlFor="card-number">Número do Cartão</Label>
                        <Input
                          id="card-number"
                          placeholder="0000 0000 0000 0000"
                          className="mt-1"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="card-expiry">Validade</Label>
                          <Input id="card-expiry" placeholder="MM/AA" className="mt-1" />
                        </div>
                        <div>
                          <Label htmlFor="card-cvv">CVV</Label>
                          <Input id="card-cvv" placeholder="123" className="mt-1" />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="card-name">Nome no Cartão</Label>
                        <Input id="card-name" placeholder="NOME COMO NO CARTÃO" className="mt-1" />
                      </div>
                    </div>
                  )}

                  <div className="flex justify-between pt-4">
                    <Button variant="ghost" onClick={goBack}>
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Voltar
                    </Button>
                    <Button onClick={handlePaymentContinue}>
                      Revisar Pedido
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step 4: Review */}
            {currentStep === 4 && (
              <Card>
                <CardHeader>
                  <CardTitle>Revisar Pedido</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Items */}
                  <div>
                    <h3 className="font-medium mb-3">Itens do Pedido</h3>
                    <div className="space-y-3">
                      {cart.items.map((item) => (
                        <div key={item.sku} className="flex items-center gap-3">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-16 h-16 object-cover rounded-md"
                          />
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{item.name}</p>
                            <p className="text-sm text-muted-foreground">
                              {item.variant} - Qtd: {item.quantity}
                            </p>
                          </div>
                          <span className="font-medium">
                            {formatPrice(item.price * item.quantity)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  {/* Address */}
                  <div>
                    <h3 className="font-medium mb-2">Endereço de Entrega</h3>
                    <p className="text-sm text-muted-foreground">
                      {address?.name}
                      <br />
                      {address?.street}, {address?.number}
                      {address?.complement && `, ${address.complement}`}
                      <br />
                      {address?.neighborhood}, {address?.city} - {address?.state}
                      <br />
                      CEP: {address?.zipCode}
                    </p>
                  </div>

                  <Separator />

                  {/* Shipping */}
                  <div>
                    <h3 className="font-medium mb-2">Entrega</h3>
                    <p className="text-sm text-muted-foreground">
                      {shippingOption?.name} - {shippingOption?.carrier}
                      <br />
                      Entrega até: {shippingOption?.estimatedDelivery}
                    </p>
                  </div>

                  <Separator />

                  {/* Payment */}
                  <div>
                    <h3 className="font-medium mb-2">Pagamento</h3>
                    <p className="text-sm text-muted-foreground">
                      {paymentMethod === "credit_card" && "Cartão de Crédito"}
                      {paymentMethod === "pix" && "PIX"}
                      {paymentMethod === "boleto" && "Boleto Bancário"}
                    </p>
                  </div>

                  <div className="flex justify-between pt-4">
                    <Button variant="ghost" onClick={goBack}>
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Voltar
                    </Button>
                    <Button onClick={handlePlaceOrder} disabled={isProcessing} size="lg" data-testid="btn-pay">
                      {isProcessing ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Processando...
                        </>
                      ) : (
                        <>
                          <Check className="h-4 w-4 mr-2" />
                          Confirmar Pedido
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Order Summary */}
          <div>
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle>Resumo</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">
                      Subtotal ({cart.items.reduce((sum, item) => sum + item.quantity, 0)} itens)
                    </span>
                    <span>{formatPrice(cart.totals.subtotal)}</span>
                  </div>
                  {cart.totals.discount > 0 && (
                    <div className="flex justify-between text-green-600 dark:text-green-400">
                      <span>Desconto</span>
                      <span>-{formatPrice(cart.totals.discount)}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Frete</span>
                    <span>
                      {shippingOption ? (
                        formatPrice(shippingOption.price)
                      ) : cart.totals.shipping === 0 ? (
                        <span className="text-green-600 dark:text-green-400">Grátis</span>
                      ) : (
                        formatPrice(cart.totals.shipping)
                      )}
                    </span>
                  </div>
                  <Separator />
                  <div className="flex justify-between text-lg font-semibold">
                    <span>Total</span>
                    <span>{formatPrice(totalWithShipping)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
