import { useState } from "react";
import { Link } from "wouter";
import { HelpCircle, Mail, Phone, MapPin, MessageSquare, ChevronDown, Search, Send, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useToast } from "@/hooks/use-toast";

const faqCategories = [
  {
    id: "pedidos",
    title: "Pedidos e Entregas",
    faqs: [
      {
        question: "Qual o prazo de entrega?",
        answer: "O prazo de entrega varia de acordo com a região. Para capitais, o prazo é de 2 a 5 dias úteis. Para regiões Sul e Sudeste, de 3 a 7 dias úteis. Para demais regiões, de 5 a 12 dias úteis.",
      },
      {
        question: "Como rastrear meu pedido?",
        answer: "Após a confirmação do pedido, você receberá um e-mail com o código de rastreamento. Você também pode acompanhar o status do pedido na seção 'Meus Pedidos' da sua conta.",
      },
      {
        question: "Vocês fazem entrega em todo o Brasil?",
        answer: "Sim! Entregamos em todo o território nacional. Algumas regiões podem ter prazos de entrega diferenciados.",
      },
      {
        question: "Posso alterar o endereço de entrega depois de fazer o pedido?",
        answer: "Alterações de endereço só podem ser feitas antes do envio do pedido. Entre em contato conosco o mais rápido possível pelo nosso canal de atendimento.",
      },
    ],
  },
  {
    id: "pagamentos",
    title: "Pagamentos",
    faqs: [
      {
        question: "Quais formas de pagamento são aceitas?",
        answer: "Aceitamos cartões de crédito (Visa, Mastercard, Elo, American Express), PIX, boleto bancário e pagamentos via MercadoPago e PagSeguro.",
      },
      {
        question: "É seguro comprar pelo site?",
        answer: "Sim! Nosso site utiliza certificado SSL e todas as transações são processadas por gateways de pagamento seguros e certificados.",
      },
      {
        question: "Em quantas vezes posso parcelar?",
        answer: "Você pode parcelar em até 3x sem juros no cartão de crédito. Para compras acima de R$ 200, oferecemos parcelamento em até 6x.",
      },
    ],
  },
  {
    id: "produtos",
    title: "Produtos",
    faqs: [
      {
        question: "Os produtos são fabricados no Brasil?",
        answer: "Sim! Todos os nossos produtos são fabricados no Brasil, com ingredientes selecionados e rigoroso controle de qualidade.",
      },
      {
        question: "Os produtos têm validade?",
        answer: "Sim, todos os nossos produtos têm prazo de validade. Garantimos que os produtos enviados tenham pelo menos 70% do prazo de validade.",
      },
      {
        question: "Vocês têm produtos sem glúten ou sem lactose?",
        answer: "Temos algumas opções para pessoas com restrições alimentares. Consulte a descrição de cada produto para informações sobre ingredientes e alérgenos.",
      },
    ],
  },
  {
    id: "trocas",
    title: "Trocas e Devoluções",
    faqs: [
      {
        question: "Como faço para trocar ou devolver um produto?",
        answer: "Entre em contato conosco em até 7 dias após o recebimento. Analisaremos o caso e providenciaremos a troca ou reembolso conforme nossa política.",
      },
      {
        question: "Recebi um produto danificado, o que fazer?",
        answer: "Entre em contato imediatamente enviando fotos do produto e da embalagem. Faremos a substituição sem custo adicional.",
      },
    ],
  },
];

export default function Support() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const filteredFaqs = faqCategories.map((category) => ({
    ...category,
    faqs: category.faqs.filter(
      (faq) =>
        faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
        faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
    ),
  })).filter((category) => category.faqs.length > 0);

  const handleContactSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500));

    setIsSubmitting(false);
    toast({
      title: "Mensagem enviada!",
      description: "Responderemos em até 24 horas.",
    });

    (e.target as HTMLFormElement).reset();
  };

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 text-primary mb-4">
            <HelpCircle className="h-6 w-6" />
            <span className="text-sm font-medium uppercase tracking-wide">Central de Ajuda</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-semibold mb-4">
            Como podemos ajudar?
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Encontre respostas para suas dúvidas ou entre em contato conosco
          </p>
        </div>

        {/* Search */}
        <div className="max-w-xl mx-auto mb-12">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Buscar nas perguntas frequentes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 h-12 text-lg"
              data-testid="search-faq"
            />
          </div>
        </div>

        {/* Quick Contact Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="text-center">
            <CardContent className="p-6">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 mb-4">
                <Phone className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Telefone</h3>
              <p className="text-muted-foreground mb-2">Seg a Sex, 9h às 18h</p>
              <a href="tel:08001234567" className="text-primary font-medium hover:underline">
                0800 123 4567
              </a>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="p-6">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 mb-4">
                <Mail className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">E-mail</h3>
              <p className="text-muted-foreground mb-2">Resposta em até 24h</p>
              <a href="mailto:contato@bauducco.com.br" className="text-primary font-medium hover:underline">
                contato@bauducco.com.br
              </a>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="p-6">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 mb-4">
                <MessageSquare className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Chat</h3>
              <p className="text-muted-foreground mb-2">Atendimento online</p>
              <Button variant="outline" size="sm">
                Iniciar chat
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* FAQ Section */}
          <div className="lg:col-span-2" id="faq">
            <h2 className="text-2xl font-semibold mb-6">Perguntas Frequentes</h2>
            
            {searchQuery && filteredFaqs.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <HelpCircle className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
                  <p className="text-lg font-medium mb-2">Nenhum resultado encontrado</p>
                  <p className="text-muted-foreground">
                    Tente buscar por outros termos ou entre em contato conosco
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-6">
                {(searchQuery ? filteredFaqs : faqCategories).map((category) => (
                  <div key={category.id}>
                    <h3 className="text-lg font-medium mb-3">{category.title}</h3>
                    <Accordion type="single" collapsible className="space-y-2">
                      {category.faqs.map((faq, index) => (
                        <AccordionItem
                          key={index}
                          value={`${category.id}-${index}`}
                          className="border rounded-lg px-4"
                        >
                          <AccordionTrigger className="text-left hover:no-underline">
                            {faq.question}
                          </AccordionTrigger>
                          <AccordionContent className="text-muted-foreground">
                            {faq.answer}
                          </AccordionContent>
                        </AccordionItem>
                      ))}
                    </Accordion>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Contact Form */}
          <div id="contato">
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle>Fale Conosco</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="contact-name">Nome</Label>
                    <Input id="contact-name" required className="mt-1" data-testid="input-contact-name" />
                  </div>
                  <div>
                    <Label htmlFor="contact-email">E-mail</Label>
                    <Input id="contact-email" type="email" required className="mt-1" data-testid="input-contact-email" />
                  </div>
                  <div>
                    <Label htmlFor="contact-subject">Assunto</Label>
                    <Input id="contact-subject" required className="mt-1" data-testid="input-contact-subject" />
                  </div>
                  <div>
                    <Label htmlFor="contact-message">Mensagem</Label>
                    <Textarea
                      id="contact-message"
                      required
                      rows={4}
                      className="mt-1 resize-none"
                      data-testid="input-contact-message"
                    />
                  </div>
                  <Button type="submit" className="w-full gap-2" disabled={isSubmitting} data-testid="btn-contact-submit">
                    {isSubmitting ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Enviando...
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4" />
                        Enviar mensagem
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Legal Links */}
        <div className="mt-16 pt-8 border-t">
          <h2 className="text-xl font-semibold mb-4">Informações Legais</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card id="privacidade" className="hover-elevate">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-2">Política de Privacidade</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Saiba como coletamos, usamos e protegemos seus dados pessoais.
                </p>
                <Button variant="outline" size="sm">Ver política completa</Button>
              </CardContent>
            </Card>
            <Card id="termos" className="hover-elevate">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-2">Termos de Uso</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Conheça as regras e condições de uso do nosso site e serviços.
                </p>
                <Button variant="outline" size="sm">Ver termos completos</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
