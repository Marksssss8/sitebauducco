import { useState } from "react";
import { Link, useSearch } from "wouter";
import { User, Package, MapPin, Heart, LogOut, ChevronRight, Eye, Truck, Check, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

// Mock data for demonstration
const mockOrders = [
  {
    id: "ORD-001",
    date: "15/11/2024",
    status: "delivered",
    total: 125.90,
    items: [
      { name: "Panettone Tradicional 500g", quantity: 2, price: 45.90 },
      { name: "Cookies Chocolate Chips", quantity: 1, price: 12.90 },
    ],
  },
  {
    id: "ORD-002",
    date: "22/11/2024",
    status: "shipped",
    total: 89.90,
    items: [
      { name: "Chocottone Gotas de Chocolate", quantity: 1, price: 54.90 },
      { name: "Torrada Integral", quantity: 2, price: 8.90 },
    ],
  },
  {
    id: "ORD-003",
    date: "28/11/2024",
    status: "processing",
    total: 199.80,
    items: [
      { name: "Kit Natal Especial", quantity: 1, price: 199.80 },
    ],
  },
];

const mockAddresses = [
  {
    id: "1",
    name: "Casa",
    street: "Rua das Flores",
    number: "123",
    complement: "Apto 45",
    neighborhood: "Jardim Primavera",
    city: "São Paulo",
    state: "SP",
    zipCode: "01234-567",
    isDefault: true,
  },
  {
    id: "2",
    name: "Trabalho",
    street: "Avenida Paulista",
    number: "1000",
    complement: "Sala 1010",
    neighborhood: "Bela Vista",
    city: "São Paulo",
    state: "SP",
    zipCode: "01310-100",
    isDefault: false,
  },
];

const statusConfig = {
  pending: { label: "Pendente", color: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300", icon: Clock },
  processing: { label: "Processando", color: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300", icon: Package },
  shipped: { label: "Enviado", color: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300", icon: Truck },
  delivered: { label: "Entregue", color: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300", icon: Check },
};

export default function MyAccount() {
  const search = useSearch();
  const params = new URLSearchParams(search);
  const initialTab = params.get("order") ? "orders" : "profile";
  
  const [activeTab, setActiveTab] = useState(initialTab);
  const { toast } = useToast();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price);
  };

  const handleProfileUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Perfil atualizado!",
      description: "Suas informações foram salvas com sucesso.",
    });
  };

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <h1 className="text-3xl font-semibold mb-8">Minha Conta</h1>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 h-auto">
            <TabsTrigger value="profile" className="gap-2 py-3">
              <User className="h-4 w-4" />
              <span className="hidden sm:inline">Perfil</span>
            </TabsTrigger>
            <TabsTrigger value="orders" className="gap-2 py-3">
              <Package className="h-4 w-4" />
              <span className="hidden sm:inline">Pedidos</span>
            </TabsTrigger>
            <TabsTrigger value="addresses" className="gap-2 py-3">
              <MapPin className="h-4 w-4" />
              <span className="hidden sm:inline">Endereços</span>
            </TabsTrigger>
            <TabsTrigger value="favorites" className="gap-2 py-3">
              <Heart className="h-4 w-4" />
              <span className="hidden sm:inline">Favoritos</span>
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Informações Pessoais</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleProfileUpdate} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="profile-name">Nome completo</Label>
                        <Input id="profile-name" defaultValue="João Silva" className="mt-1" />
                      </div>
                      <div>
                        <Label htmlFor="profile-email">E-mail</Label>
                        <Input id="profile-email" type="email" defaultValue="joao@email.com" className="mt-1" />
                      </div>
                      <div>
                        <Label htmlFor="profile-phone">Telefone</Label>
                        <Input id="profile-phone" defaultValue="(11) 99999-9999" className="mt-1" />
                      </div>
                      <div>
                        <Label htmlFor="profile-cpf">CPF</Label>
                        <Input id="profile-cpf" defaultValue="***.***.***-00" disabled className="mt-1" />
                      </div>
                    </div>
                    <Button type="submit">Salvar alterações</Button>
                  </form>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Segurança</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button variant="outline" className="w-full justify-between">
                    Alterar senha
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  <Separator />
                  <Button variant="ghost" className="w-full justify-start text-destructive gap-2">
                    <LogOut className="h-4 w-4" />
                    Sair da conta
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Orders Tab */}
          <TabsContent value="orders">
            <div className="space-y-4">
              {mockOrders.map((order) => {
                const statusInfo = statusConfig[order.status as keyof typeof statusConfig];
                const StatusIcon = statusInfo.icon;

                return (
                  <Card key={order.id} data-testid={`order-${order.id}`}>
                    <CardContent className="p-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                        <div>
                          <div className="flex items-center gap-3">
                            <h3 className="font-semibold">Pedido #{order.id}</h3>
                            <Badge className={statusInfo.color}>
                              <StatusIcon className="h-3 w-3 mr-1" />
                              {statusInfo.label}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">
                            Realizado em {order.date}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-lg">{formatPrice(order.total)}</p>
                          <Button variant="ghost" size="sm" className="gap-1">
                            <Eye className="h-4 w-4" />
                            Ver detalhes
                          </Button>
                        </div>
                      </div>
                      <Separator className="my-4" />
                      <div className="space-y-2">
                        {order.items.map((item, index) => (
                          <div key={index} className="flex justify-between text-sm">
                            <span className="text-muted-foreground">
                              {item.quantity}x {item.name}
                            </span>
                            <span>{formatPrice(item.price * item.quantity)}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          {/* Addresses Tab */}
          <TabsContent value="addresses">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {mockAddresses.map((address) => (
                <Card key={address.id} className={address.isDefault ? "border-primary" : ""}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-primary" />
                        <span className="font-semibold">{address.name}</span>
                        {address.isDefault && (
                          <Badge variant="secondary" className="text-xs">Padrão</Badge>
                        )}
                      </div>
                      <Button variant="ghost" size="sm">Editar</Button>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {address.street}, {address.number}
                      {address.complement && `, ${address.complement}`}
                      <br />
                      {address.neighborhood}, {address.city} - {address.state}
                      <br />
                      CEP: {address.zipCode}
                    </p>
                  </CardContent>
                </Card>
              ))}
              <Card className="border-dashed">
                <CardContent className="p-6 flex flex-col items-center justify-center min-h-[150px]">
                  <MapPin className="h-8 w-8 text-muted-foreground mb-2" />
                  <Button variant="outline">Adicionar novo endereço</Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Favorites Tab */}
          <TabsContent value="favorites">
            <Card>
              <CardContent className="p-12 text-center">
                <Heart className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">Nenhum favorito ainda</h3>
                <p className="text-muted-foreground mb-6">
                  Salve seus produtos favoritos para encontrá-los facilmente depois
                </p>
                <Button asChild>
                  <Link href="/products">Explorar produtos</Link>
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
