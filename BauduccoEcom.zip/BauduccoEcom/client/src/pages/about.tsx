import { Link } from "wouter";
import { ArrowRight, Award, Heart, Leaf, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const timeline = [
  {
    year: "1952",
    title: "O Início",
    description: "Carlo Bauducco funda a empresa em São Paulo, trazendo receitas tradicionais italianas.",
  },
  {
    year: "1962",
    title: "Primeiro Panettone",
    description: "Lançamento do primeiro panettone Bauducco, que se tornaria um ícone do Natal brasileiro.",
  },
  {
    year: "1980",
    title: "Expansão Nacional",
    description: "A marca se consolida como líder de mercado em todo o Brasil.",
  },
  {
    year: "2000",
    title: "Internacionalização",
    description: "Início das exportações para Estados Unidos, América Latina e Europa.",
  },
  {
    year: "2020",
    title: "Inovação Contínua",
    description: "Lançamento de novas linhas de produtos e compromisso com sustentabilidade.",
  },
];

const values = [
  {
    icon: Heart,
    title: "Paixão pela Qualidade",
    description: "Cada produto é feito com os melhores ingredientes e processos rigorosos de qualidade.",
  },
  {
    icon: Users,
    title: "Família",
    description: "Valorizamos os momentos em família e trabalhamos para torná-los ainda mais especiais.",
  },
  {
    icon: Leaf,
    title: "Sustentabilidade",
    description: "Compromisso com práticas sustentáveis em toda a nossa cadeia produtiva.",
  },
  {
    icon: Award,
    title: "Tradição",
    description: "Mais de 70 anos preservando receitas e sabores que fazem parte da vida dos brasileiros.",
  },
];

export default function About() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[400px] md:min-h-[500px] flex items-center">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: "url(https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=1920&q=80)",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-transparent" />
        <div className="relative max-w-7xl mx-auto px-4 md:px-8 py-16">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-semibold text-white mb-4">
            Nossa História
          </h1>
          <p className="text-xl text-white/90 max-w-2xl">
            Há mais de 70 anos adoçando os momentos especiais das famílias brasileiras
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-12 md:py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
            <div>
              <h2 className="text-2xl md:text-3xl font-semibold mb-6">
                Uma tradição que atravessa gerações
              </h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  A história da Bauducco começou em 1952, quando Carlo Bauducco trouxe da Itália 
                  não apenas receitas, mas o sonho de criar produtos que fariam parte dos momentos 
                  mais especiais das famílias brasileiras.
                </p>
                <p>
                  O que começou como uma pequena padaria em São Paulo transformou-se em uma das 
                  maiores empresas de alimentos do país, sempre mantendo a mesma dedicação à 
                  qualidade e ao sabor que encanta gerações.
                </p>
                <p>
                  Hoje, a Bauducco está presente em milhões de lares brasileiros e em mais de 
                  50 países, levando o sabor da tradição italiana para todo o mundo.
                </p>
              </div>
            </div>
            <div className="relative aspect-square rounded-lg overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1574085733277-851d9d856a3a?w=800&h=800&fit=crop"
                alt="Produção Bauducco"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-12 md:py-16 bg-accent/30">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <h2 className="text-2xl md:text-3xl font-semibold text-center mb-12">
            Nossa Trajetória
          </h2>
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-border hidden md:block" />
            
            <div className="space-y-8">
              {timeline.map((item, index) => (
                <div
                  key={item.year}
                  className={`flex flex-col md:flex-row items-center gap-4 md:gap-8 ${
                    index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                  }`}
                >
                  <div className={`flex-1 ${index % 2 === 0 ? "md:text-right" : "md:text-left"}`}>
                    <Card>
                      <CardContent className="p-6">
                        <span className="text-primary font-bold text-lg">{item.year}</span>
                        <h3 className="text-xl font-semibold mt-2 mb-2">{item.title}</h3>
                        <p className="text-muted-foreground">{item.description}</p>
                      </CardContent>
                    </Card>
                  </div>
                  <div className="hidden md:flex items-center justify-center w-12 h-12 rounded-full bg-primary text-primary-foreground font-bold z-10">
                    {index + 1}
                  </div>
                  <div className="flex-1 hidden md:block" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-12 md:py-16 lg:py-20" id="sustentabilidade">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <h2 className="text-2xl md:text-3xl font-semibold text-center mb-4">
            Nossos Valores
          </h2>
          <p className="text-muted-foreground text-center max-w-2xl mx-auto mb-12">
            Os pilares que guiam tudo o que fazemos
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value) => (
              <Card key={value.title} className="text-center">
                <CardContent className="p-6">
                  <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary/10 mb-4">
                    <value.icon className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{value.title}</h3>
                  <p className="text-sm text-muted-foreground">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Careers CTA */}
      <section className="py-12 md:py-16 bg-primary text-primary-foreground" id="carreiras">
        <div className="max-w-7xl mx-auto px-4 md:px-8 text-center">
          <h2 className="text-2xl md:text-3xl font-semibold mb-4">
            Faça parte do nosso time
          </h2>
          <p className="text-primary-foreground/90 max-w-2xl mx-auto mb-8">
            Estamos sempre em busca de talentos apaixonados que queiram fazer a diferença. 
            Venha construir o futuro da Bauducco conosco.
          </p>
          <Button variant="secondary" size="lg" asChild>
            <a href="https://careers.bauducco.com" target="_blank" rel="noopener noreferrer">
              Ver vagas abertas
              <ArrowRight className="h-4 w-4 ml-2" />
            </a>
          </Button>
        </div>
      </section>

      {/* Press Section */}
      <section className="py-12 md:py-16" id="imprensa">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <h2 className="text-2xl md:text-3xl font-semibold text-center mb-4">
            Sala de Imprensa
          </h2>
          <p className="text-muted-foreground text-center max-w-2xl mx-auto mb-8">
            Acesse nossos materiais de imprensa, logotipos e informações para a mídia
          </p>
          <div className="flex justify-center gap-4">
            <Button variant="outline" asChild>
              <Link href="/support#contato">
                Contato para Imprensa
              </Link>
            </Button>
            <Button variant="ghost" asChild>
              <a href="/press-kit.zip" download>
                Baixar Press Kit
              </a>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
