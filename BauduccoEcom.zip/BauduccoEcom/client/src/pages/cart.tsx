import { Link } from "wouter";
import { ShoppingCart, Minus, Plus, Trash2, Tag, X, ArrowLeft, ArrowRight, ShoppingBag } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useCart } from "@/contexts/cart-context";
import { useToast } from "@/hooks/use-toast";

export default function Cart() {
  const { cart, removeItem, updateQuantity, applyPromoCode, removePromoCode } = useCart();
  const [promoCode, setPromoCode] = useState("");
  const [isApplyingPromo, setIsApplyingPromo] = useState(false);
  const { toast } = useToast();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(price);
  };

  const handleApplyPromo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoCode.trim()) return;

    setIsApplyingPromo(true);
    const result = await applyPromoCode(promoCode);
    setIsApplyingPromo(false);

    if (result.success) {
      toast({
        title: "Cupom aplicado!",
        description: result.message,
      });
      setPromoCode("");
    } else {
      toast({
        title: "Erro ao aplicar cupom",
        description: result.message,
        variant: "destructive",
      });
    }
  };

  if (cart.items.length === 0) {
    return (
      <div className="min-h-screen py-16">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="text-center max-w-md mx-auto">
            <ShoppingBag className="h-24 w-24 text-muted-foreground/30 mx-auto mb-6" />
            <h1 className="text-2xl font-semibold mb-4">Seu carrinho está vazio</h1>
            <p className="text-muted-foreground mb-8">
              Que tal explorar nossos produtos deliciosos e adicionar alguns ao carrinho?
            </p>
            <Button asChild size="lg">
              <Link href="/products">
                <ShoppingCart className="h-5 w-5 mr-2" />
                Explorar produtos
              </Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <h1 className="text-3xl font-semibold mb-8 flex items-center gap-3">
          <ShoppingCart className="h-8 w-8" />
          Carrinho de Compras
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cart.items.map((item) => (
              <Card key={item.sku} data-testid={`cart-item-${item.sku}`}>
                <CardContent className="p-4 md:p-6">
                  <div className="flex gap-4 md:gap-6">
                    <Link href={`/product/${item.productId}`}>
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-24 h-24 md:w-32 md:h-32 object-cover rounded-md"
                      />
                    </Link>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <Link href={`/product/${item.productId}`}>
                            <h3 className="font-medium hover:text-primary transition-colors line-clamp-2">
                              {item.name}
                            </h3>
                          </Link>
                          <p className="text-sm text-muted-foreground mt-1">
                            {item.variant}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeItem(item.sku)}
                          className="text-muted-foreground hover:text-destructive flex-shrink-0"
                          data-testid={`btn-remove-${item.sku}`}
                          aria-label="Remover item"
                        >
                          <Trash2 className="h-5 w-5" />
                        </Button>
                      </div>

                      <div className="flex items-end justify-between mt-4">
                        <div className="flex items-center border rounded-md">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-9 w-9"
                            onClick={() => updateQuantity(item.sku, item.quantity - 1)}
                            data-testid={`btn-decrease-${item.sku}`}
                            aria-label="Diminuir quantidade"
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                          <span className="w-12 text-center font-medium" data-testid={`quantity-${item.sku}`}>
                            {item.quantity}
                          </span>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-9 w-9"
                            onClick={() => updateQuantity(item.sku, item.quantity + 1)}
                            data-testid={`btn-increase-${item.sku}`}
                            aria-label="Aumentar quantidade"
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                        <div className="text-right">
                          {item.compareAtPrice && item.compareAtPrice > item.price && (
                            <span className="text-sm text-muted-foreground line-through block">
                              {formatPrice(item.compareAtPrice * item.quantity)}
                            </span>
                          )}
                          <span className="text-lg font-semibold text-primary">
                            {formatPrice(item.price * item.quantity)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            <div className="flex items-center justify-between pt-4">
              <Button variant="ghost" asChild>
                <Link href="/products">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Continuar comprando
                </Link>
              </Button>
            </div>
          </div>

          {/* Order Summary */}
          <div>
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle>Resumo do Pedido</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Promo Code */}
                <form onSubmit={handleApplyPromo} className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      type="text"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      placeholder="Cupom de desconto"
                      className="pl-9"
                      data-testid="promo-code-input"
                    />
                  </div>
                  <Button
                    type="submit"
                    variant="secondary"
                    disabled={isApplyingPromo || !promoCode.trim()}
                    data-testid="btn-apply-promo"
                  >
                    Aplicar
                  </Button>
                </form>

                {/* Applied Promos */}
                {cart.appliedPromos.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {cart.appliedPromos.map((code) => (
                      <Badge key={code} variant="secondary" className="gap-1">
                        <Tag className="h-3 w-3" />
                        {code}
                        <button
                          onClick={() => removePromoCode(code)}
                          className="ml-1 hover:text-destructive"
                          aria-label="Remover cupom"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}

                <Separator />

                {/* Totals */}
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span>{formatPrice(cart.totals.subtotal)}</span>
                  </div>
                  {cart.totals.discount > 0 && (
                    <div className="flex justify-between text-green-600 dark:text-green-400">
                      <span>Desconto</span>
                      <span>-{formatPrice(cart.totals.discount)}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Frete</span>
                    <span>
                      {cart.totals.shipping === 0 ? (
                        <span className="text-green-600 dark:text-green-400">Grátis</span>
                      ) : (
                        formatPrice(cart.totals.shipping)
                      )}
                    </span>
                  </div>
                  <Separator />
                  <div className="flex justify-between text-lg font-semibold">
                    <span>Total</span>
                    <span>{formatPrice(cart.totals.total)}</span>
                  </div>
                </div>

                {cart.totals.subtotal < 150 && (
                  <p className="text-sm text-muted-foreground text-center bg-accent/50 p-3 rounded-md">
                    Faltam <strong>{formatPrice(150 - cart.totals.subtotal)}</strong> para frete grátis!
                  </p>
                )}

                <Button className="w-full gap-2" size="lg" asChild data-testid="btn-go-to-checkout">
                  <Link href="/checkout">
                    Finalizar compra
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
