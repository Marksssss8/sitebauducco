import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(server: Server, app: Express): Promise<void> {
  // Products API
  app.get("/api/products", async (req, res) => {
    try {
      const { category, tag, featured, limit, q, promo, related, ids } = req.query;
      
      const filters: any = {};
      if (category) filters.category = category as string;
      if (tag || promo) filters.tag = (tag || promo) as string;
      if (featured === "true") filters.featured = true;
      if (limit) filters.limit = parseInt(limit as string, 10);
      if (q) filters.q = q as string;

      const products = await storage.getProducts(filters);
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.get("/api/product/:slug", async (req, res) => {
    try {
      const product = await storage.getProductBySlug(req.params.slug);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  // Recipes API
  app.get("/api/recipes", async (req, res) => {
    try {
      const { category, difficulty, featured, q } = req.query;
      
      const filters: any = {};
      if (category) filters.category = category as string;
      if (difficulty) filters.difficulty = difficulty as string;
      if (featured === "true") filters.featured = true;
      if (q) filters.q = q as string;

      const recipes = await storage.getRecipes(filters);
      res.json(recipes);
    } catch (error) {
      console.error("Error fetching recipes:", error);
      res.status(500).json({ error: "Failed to fetch recipes" });
    }
  });

  app.get("/api/recipe/:slug", async (req, res) => {
    try {
      const recipe = await storage.getRecipeBySlug(req.params.slug);
      if (!recipe) {
        return res.status(404).json({ error: "Recipe not found" });
      }
      res.json(recipe);
    } catch (error) {
      console.error("Error fetching recipe:", error);
      res.status(500).json({ error: "Failed to fetch recipe" });
    }
  });

  // Promotions API
  app.get("/api/promotions", async (req, res) => {
    try {
      const promotions = await storage.getPromotions();
      res.json(promotions);
    } catch (error) {
      console.error("Error fetching promotions:", error);
      res.status(500).json({ error: "Failed to fetch promotions" });
    }
  });

  app.post("/api/promotions/validate", async (req, res) => {
    try {
      const { code } = req.body;
      if (!code) {
        return res.status(400).json({ valid: false, message: "Código não informado" });
      }

      const promotion = await storage.getPromotionByCode(code);
      if (!promotion) {
        return res.status(404).json({ valid: false, message: "Cupom inválido" });
      }

      // Check dates
      const now = new Date();
      const start = new Date(promotion.start);
      const end = new Date(promotion.end);

      if (now < start || now > end) {
        return res.status(400).json({ valid: false, message: "Cupom expirado" });
      }

      res.json({ valid: true, promotion });
    } catch (error) {
      console.error("Error validating promotion:", error);
      res.status(500).json({ error: "Failed to validate promotion" });
    }
  });

  // Promo Pages API
  app.get("/api/promo/:campaign", async (req, res) => {
    try {
      const promoPage = await storage.getPromoPage(req.params.campaign);
      if (!promoPage) {
        return res.status(404).json({ error: "Promo page not found" });
      }
      res.json(promoPage);
    } catch (error) {
      console.error("Error fetching promo page:", error);
      res.status(500).json({ error: "Failed to fetch promo page" });
    }
  });

  // CEP Lookup API (mock implementation)
  app.get("/api/cep/:cep", async (req, res) => {
    try {
      const cep = req.params.cep.replace(/\D/g, "");
      
      if (cep.length !== 8) {
        return res.status(400).json({ error: "CEP inválido" });
      }

      // Mock CEP data - in production, would call ViaCEP or similar API
      const mockAddresses: Record<string, any> = {
        "01310100": { cep: "01310-100", street: "Avenida Paulista", neighborhood: "Bela Vista", city: "São Paulo", state: "SP" },
        "22041080": { cep: "22041-080", street: "Avenida Atlântica", neighborhood: "Copacabana", city: "Rio de Janeiro", state: "RJ" },
        "30130000": { cep: "30130-000", street: "Avenida Afonso Pena", neighborhood: "Centro", city: "Belo Horizonte", state: "MG" },
      };

      const address = mockAddresses[cep] || {
        cep: cep.replace(/(\d{5})(\d{3})/, "$1-$2"),
        street: "Rua Exemplo",
        neighborhood: "Centro",
        city: "São Paulo",
        state: "SP",
      };

      res.json(address);
    } catch (error) {
      console.error("Error looking up CEP:", error);
      res.status(500).json({ error: "Failed to lookup CEP" });
    }
  });

  // Shipping Calculator API (mock implementation)
  app.post("/api/shipping/calculate", async (req, res) => {
    try {
      const { cep } = req.body;
      
      if (!cep || cep.replace(/\D/g, "").length !== 8) {
        return res.status(400).json({ error: "CEP inválido" });
      }

      const today = new Date();
      
      const options = [
        {
          id: "sedex",
          name: "SEDEX",
          carrier: "Correios",
          price: 25.90,
          estimatedDays: 3,
          estimatedDelivery: new Date(today.getTime() + 3 * 24 * 60 * 60 * 1000).toLocaleDateString("pt-BR"),
        },
        {
          id: "pac",
          name: "PAC",
          carrier: "Correios",
          price: 15.90,
          estimatedDays: 7,
          estimatedDelivery: new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString("pt-BR"),
        },
        {
          id: "express",
          name: "Entrega Expressa",
          carrier: "Loggi",
          price: 35.90,
          estimatedDays: 1,
          estimatedDelivery: new Date(today.getTime() + 1 * 24 * 60 * 60 * 1000).toLocaleDateString("pt-BR"),
        },
      ];

      res.json(options);
    } catch (error) {
      console.error("Error calculating shipping:", error);
      res.status(500).json({ error: "Failed to calculate shipping" });
    }
  });

  // Newsletter API
  app.post("/api/newsletter/subscribe", async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email || !email.includes("@")) {
        return res.status(400).json({ error: "E-mail inválido" });
      }

      await storage.subscribeNewsletter(email);
      res.json({ success: true, message: "Cadastrado com sucesso!" });
    } catch (error) {
      console.error("Error subscribing to newsletter:", error);
      res.status(500).json({ error: "Failed to subscribe" });
    }
  });

  // FAQ API
  app.get("/api/faqs", async (req, res) => {
    try {
      const { category } = req.query;
      const faqs = await storage.getFaqs(category as string);
      res.json(faqs);
    } catch (error) {
      console.error("Error fetching FAQs:", error);
      res.status(500).json({ error: "Failed to fetch FAQs" });
    }
  });

  // Contact Form API
  app.post("/api/contact", async (req, res) => {
    try {
      const { name, email, subject, message } = req.body;
      
      if (!name || !email || !subject || !message) {
        return res.status(400).json({ error: "Todos os campos são obrigatórios" });
      }

      // In production, would send email or save to database
      console.log("Contact form submission:", { name, email, subject, message });
      
      res.json({ success: true, message: "Mensagem enviada com sucesso!" });
    } catch (error) {
      console.error("Error processing contact form:", error);
      res.status(500).json({ error: "Failed to process contact form" });
    }
  });

  // Mock Order API
  app.post("/api/orders", async (req, res) => {
    try {
      const { cartId, address, shippingOptionId, payment } = req.body;
      
      // Mock order creation
      const orderId = `ORD-${Date.now()}`;
      
      res.json({
        success: true,
        orderId,
        message: "Pedido criado com sucesso!",
      });
    } catch (error) {
      console.error("Error creating order:", error);
      res.status(500).json({ error: "Failed to create order" });
    }
  });

  // Search API
  app.get("/api/search", async (req, res) => {
    try {
      const { q } = req.query;
      
      if (!q || typeof q !== "string" || q.length < 2) {
        return res.json({ products: [], recipes: [] });
      }

      const [products, recipes] = await Promise.all([
        storage.getProducts({ q, limit: 5 }),
        storage.getRecipes({ q }),
      ]);

      const suggestions = [
        ...products.map(p => ({
          type: "product" as const,
          id: p.id,
          name: p.name,
          image: p.images[0],
          href: `/product/${p.slug}`,
        })),
        ...recipes.slice(0, 3).map(r => ({
          type: "recipe" as const,
          id: r.id,
          name: r.title,
          image: r.image,
          href: `/blog/recipes/${r.slug}`,
        })),
      ];

      res.json({ suggestions, products, recipes: recipes.slice(0, 3) });
    } catch (error) {
      console.error("Error searching:", error);
      res.status(500).json({ error: "Failed to search" });
    }
  });
}
