import type { Product, Recipe, Promotion, Cart, Order, PromoPage, FAQ, Newsletter, ShippingOption } from "@shared/schema";

// Seed data for products
const products: Product[] = [
  {
    id: "1",
    sku: "PAN-TRAD-500",
    name: "Panettone Tradicional 500g",
    slug: "panettone-tradicional-500g",
    descriptionHtml: "<p>O autêntico sabor italiano que você ama. Feito com frutas cristalizadas selecionadas e uvas passas, seguindo a receita tradicional da família Bauducco desde 1952.</p><p>Perfeito para compartilhar em família durante as festas de fim de ano.</p>",
    shortDescription: "Panettone tradicional com frutas cristalizadas e uvas passas",
    categories: ["panettones"],
    images: ["https://images.unsplash.com/photo-1574085733277-851d9d856a3a?w=600&h=600&fit=crop"],
    variants: [
      { sku: "PAN-TRAD-500", name: "500g", weight: "500g", price: 45.90, compareAtPrice: 54.90, inventory: 100 },
      { sku: "PAN-TRAD-750", name: "750g", weight: "750g", price: 62.90, compareAtPrice: 74.90, inventory: 50 },
      { sku: "PAN-TRAD-1000", name: "1kg", weight: "1000g", price: 79.90, compareAtPrice: 89.90, inventory: 30 },
    ],
    nutritionalInfo: {
      servingSize: "80g (1 fatia)",
      calories: 280,
      totalFat: "9g",
      saturatedFat: "4g",
      transFat: "0g",
      cholesterol: "45mg",
      sodium: "180mg",
      totalCarbs: "45g",
      dietaryFiber: "2g",
      sugars: "22g",
      protein: "5g",
    },
    tags: ["tradicional", "natal", "destaque"],
    availability: "in_stock",
    featured: true,
    rating: 4.8,
    reviewCount: 256,
  },
  {
    id: "2",
    sku: "CHOC-GOTAS-500",
    name: "Chocottone Gotas de Chocolate 500g",
    slug: "chocottone-gotas-chocolate-500g",
    descriptionHtml: "<p>Para os amantes de chocolate! Massa fofinha recheada com deliciosas gotas de chocolate ao leite que derretem na boca.</p><p>A combinação perfeita entre a tradição do panettone e o irresistível sabor do chocolate.</p>",
    shortDescription: "Panettone com gotas de chocolate ao leite",
    categories: ["panettones"],
    images: ["https://images.unsplash.com/photo-1509440159596-0249088772ff?w=600&h=600&fit=crop"],
    variants: [
      { sku: "CHOC-GOTAS-500", name: "500g", weight: "500g", price: 54.90, compareAtPrice: 64.90, inventory: 80 },
      { sku: "CHOC-GOTAS-750", name: "750g", weight: "750g", price: 72.90, inventory: 40 },
    ],
    nutritionalInfo: {
      servingSize: "80g (1 fatia)",
      calories: 320,
      totalFat: "12g",
      saturatedFat: "6g",
      transFat: "0g",
      cholesterol: "50mg",
      sodium: "160mg",
      totalCarbs: "48g",
      dietaryFiber: "2g",
      sugars: "28g",
      protein: "6g",
    },
    tags: ["chocolate", "chocottone", "natal", "destaque"],
    availability: "in_stock",
    featured: true,
    rating: 4.9,
    reviewCount: 189,
  },
  {
    id: "3",
    sku: "COOK-CHOC-200",
    name: "Cookies Chocolate Chips 200g",
    slug: "cookies-chocolate-chips-200g",
    descriptionHtml: "<p>Cookies crocantes por fora e macios por dentro, recheados com generosas gotas de chocolate.</p><p>Perfeitos para acompanhar seu café ou como lanche a qualquer hora do dia.</p>",
    shortDescription: "Cookies com gotas de chocolate crocantes",
    categories: ["biscoitos"],
    images: ["https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=600&h=600&fit=crop"],
    variants: [
      { sku: "COOK-CHOC-200", name: "200g", weight: "200g", price: 12.90, inventory: 200 },
      { sku: "COOK-CHOC-400", name: "400g", weight: "400g", price: 22.90, inventory: 100 },
    ],
    tags: ["cookies", "chocolate", "lanche"],
    availability: "in_stock",
    featured: true,
    rating: 4.7,
    reviewCount: 143,
  },
  {
    id: "4",
    sku: "WAFER-CHOC-140",
    name: "Wafer Recheado Chocolate 140g",
    slug: "wafer-recheado-chocolate-140g",
    descriptionHtml: "<p>Camadas crocantes de wafer intercaladas com cremoso recheio de chocolate.</p><p>O equilíbrio perfeito entre crocância e cremosidade.</p>",
    shortDescription: "Wafer crocante com recheio de chocolate",
    categories: ["biscoitos"],
    images: ["https://images.unsplash.com/photo-1599490659213-e2b9527bd087?w=600&h=600&fit=crop"],
    variants: [
      { sku: "WAFER-CHOC-140", name: "140g", weight: "140g", price: 8.90, inventory: 150 },
    ],
    tags: ["wafers", "chocolate", "lanche"],
    availability: "in_stock",
    rating: 4.5,
    reviewCount: 98,
  },
  {
    id: "5",
    sku: "BOLO-CHOC-400",
    name: "Bolo de Chocolate 400g",
    slug: "bolo-chocolate-400g",
    descriptionHtml: "<p>Bolo fofinho de chocolate com cobertura cremosa.</p><p>Pronto para servir em qualquer ocasião especial.</p>",
    shortDescription: "Bolo pronto de chocolate com cobertura",
    categories: ["bolos"],
    images: ["https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=600&h=600&fit=crop"],
    variants: [
      { sku: "BOLO-CHOC-400", name: "400g", weight: "400g", price: 24.90, inventory: 60 },
    ],
    tags: ["bolo", "chocolate", "pronto"],
    availability: "in_stock",
    featured: true,
    rating: 4.6,
    reviewCount: 87,
  },
  {
    id: "6",
    sku: "TORR-TRAD-160",
    name: "Torrada Tradicional 160g",
    slug: "torrada-tradicional-160g",
    descriptionHtml: "<p>Torradas crocantes e douradas, perfeitas para o café da manhã.</p><p>Ideais para acompanhar geleias, manteigas ou seu recheio favorito.</p>",
    shortDescription: "Torradas crocantes para seu café da manhã",
    categories: ["torradas"],
    images: ["https://images.unsplash.com/photo-1509440159596-0249088772ff?w=600&h=600&fit=crop"],
    variants: [
      { sku: "TORR-TRAD-160", name: "160g", weight: "160g", price: 6.90, inventory: 200 },
      { sku: "TORR-TRAD-320", name: "320g", weight: "320g", price: 11.90, inventory: 100 },
    ],
    tags: ["torradas", "tradicional", "cafe-da-manha"],
    availability: "in_stock",
    rating: 4.4,
    reviewCount: 156,
  },
  {
    id: "7",
    sku: "TORR-INT-160",
    name: "Torrada Integral 160g",
    slug: "torrada-integral-160g",
    descriptionHtml: "<p>Torradas integrais com grãos selecionados.</p><p>Opção mais saudável e nutritiva para seu dia a dia.</p>",
    shortDescription: "Torradas integrais nutritivas",
    categories: ["torradas"],
    images: ["https://images.unsplash.com/photo-1509440159596-0249088772ff?w=600&h=600&fit=crop"],
    variants: [
      { sku: "TORR-INT-160", name: "160g", weight: "160g", price: 7.90, inventory: 150 },
    ],
    tags: ["torradas", "integral", "saudavel"],
    availability: "in_stock",
    rating: 4.3,
    reviewCount: 89,
  },
  {
    id: "8",
    sku: "PAN-TRUFA-500",
    name: "Panettone Trufado 500g",
    slug: "panettone-trufado-500g",
    descriptionHtml: "<p>Panettone com recheio cremoso de trufa de chocolate.</p><p>Uma experiência luxuosa para paladares exigentes.</p>",
    shortDescription: "Panettone com recheio de trufa de chocolate",
    categories: ["panettones"],
    images: ["https://images.unsplash.com/photo-1574085733277-851d9d856a3a?w=600&h=600&fit=crop"],
    variants: [
      { sku: "PAN-TRUFA-500", name: "500g", weight: "500g", price: 89.90, compareAtPrice: 109.90, inventory: 40 },
    ],
    tags: ["trufa", "premium", "natal"],
    availability: "in_stock",
    rating: 4.9,
    reviewCount: 67,
  },
  {
    id: "9",
    sku: "KIT-NATAL-ESP",
    name: "Kit Natal Especial",
    slug: "kit-natal-especial",
    descriptionHtml: "<p>Kit completo com Panettone Tradicional 500g + Chocottone 500g + Cookies 200g.</p><p>O presente perfeito para as festas de fim de ano.</p>",
    shortDescription: "Kit com panettone, chocottone e cookies",
    categories: ["panettones"],
    images: ["https://images.unsplash.com/photo-1512389142860-9c449e58a814?w=600&h=600&fit=crop"],
    variants: [
      { sku: "KIT-NATAL-ESP", name: "Kit Completo", weight: "1200g", price: 99.90, compareAtPrice: 129.90, inventory: 25 },
    ],
    tags: ["kit", "presente", "natal", "destaque"],
    availability: "in_stock",
    featured: true,
    rating: 4.8,
    reviewCount: 45,
  },
  {
    id: "10",
    sku: "BISAM-150",
    name: "Biscoitos Amanteigados 150g",
    slug: "biscoitos-amanteigados-150g",
    descriptionHtml: "<p>Biscoitos amanteigados de receita tradicional.</p><p>Derretem na boca com sabor suave de manteiga.</p>",
    shortDescription: "Biscoitos amanteigados tradicionais",
    categories: ["biscoitos"],
    images: ["https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=600&h=600&fit=crop"],
    variants: [
      { sku: "BISAM-150", name: "150g", weight: "150g", price: 14.90, inventory: 120 },
    ],
    tags: ["amanteigados", "tradicional"],
    availability: "in_stock",
    rating: 4.6,
    reviewCount: 112,
  },
];

// Seed data for recipes
const recipes: Recipe[] = [
  {
    id: "1",
    title: "Rabanada de Panettone",
    slug: "rabanada-panettone",
    description: "Uma versão sofisticada da tradicional rabanada usando panettone. Perfeita para as festas de fim de ano.",
    image: "https://images.unsplash.com/photo-1574085733277-851d9d856a3a?w=800&h=600&fit=crop",
    prepTime: 15,
    cookTime: 10,
    servings: 6,
    difficulty: "easy",
    ingredients: [
      { item: "Panettone Bauducco", amount: "1 unidade (500g)" },
      { item: "Ovos", amount: "4 unidades" },
      { item: "Leite", amount: "1 xícara" },
      { item: "Canela em pó", amount: "1 colher de chá" },
      { item: "Açúcar", amount: "1/2 xícara" },
      { item: "Manteiga", amount: "2 colheres de sopa" },
    ],
    instructions: [
      "Corte o panettone em fatias de aproximadamente 2cm de espessura.",
      "Em uma tigela, bata os ovos com o leite e metade da canela.",
      "Aqueça a manteiga em uma frigideira em fogo médio.",
      "Passe cada fatia de panettone na mistura de ovos, deixando absorver bem.",
      "Frite as fatias até dourar dos dois lados, cerca de 2 minutos cada lado.",
      "Misture o açúcar com o restante da canela e polvilhe sobre as rabanadas ainda quentes.",
    ],
    tips: [
      "Use panettone do dia anterior para uma textura melhor.",
      "Sirva com calda de chocolate ou leite condensado.",
    ],
    relatedProducts: ["1", "2"],
    categories: ["sobremesas", "natal"],
    featured: true,
  },
  {
    id: "2",
    title: "Torta de Cookies e Chocolate",
    slug: "torta-cookies-chocolate",
    description: "Uma torta cremosa com base de cookies e recheio de chocolate. Irresistível!",
    image: "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=800&h=600&fit=crop",
    prepTime: 30,
    cookTime: 0,
    servings: 8,
    difficulty: "medium",
    ingredients: [
      { item: "Cookies Bauducco Chocolate Chips", amount: "400g" },
      { item: "Manteiga derretida", amount: "100g" },
      { item: "Creme de leite", amount: "400ml" },
      { item: "Chocolate ao leite", amount: "300g" },
      { item: "Chocolate amargo", amount: "100g" },
    ],
    instructions: [
      "Triture os cookies no processador até obter uma farofa fina.",
      "Misture com a manteiga derretida e forre o fundo de uma forma de 24cm.",
      "Leve à geladeira por 30 minutos.",
      "Aqueça o creme de leite e derreta os chocolates picados.",
      "Despeje sobre a base de cookies e leve à geladeira por 4 horas.",
      "Decore com cookies triturados por cima antes de servir.",
    ],
    tips: [
      "Pode ser feita um dia antes da festa.",
      "Sirva gelada com chantilly.",
    ],
    relatedProducts: ["3"],
    categories: ["sobremesas", "festas"],
    featured: true,
  },
  {
    id: "3",
    title: "Pudim de Panettone",
    slug: "pudim-panettone",
    description: "Uma sobremesa clássica reinventada com panettone. Cremoso e reconfortante.",
    image: "https://images.unsplash.com/photo-1574085733277-851d9d856a3a?w=800&h=600&fit=crop",
    prepTime: 20,
    cookTime: 60,
    servings: 10,
    difficulty: "medium",
    ingredients: [
      { item: "Panettone Bauducco", amount: "1 unidade (500g)" },
      { item: "Leite", amount: "500ml" },
      { item: "Ovos", amount: "5 unidades" },
      { item: "Açúcar", amount: "1 xícara" },
      { item: "Leite condensado", amount: "1 lata" },
      { item: "Essência de baunilha", amount: "1 colher de chá" },
    ],
    instructions: [
      "Pique o panettone em cubos e distribua em uma forma caramelizada.",
      "Bata no liquidificador o leite, ovos, leite condensado e baunilha.",
      "Despeje a mistura sobre o panettone e deixe descansar 15 minutos.",
      "Asse em banho-maria a 180°C por 1 hora.",
      "Deixe esfriar e leve à geladeira por 4 horas antes de desenformar.",
    ],
    relatedProducts: ["1"],
    categories: ["sobremesas", "natal"],
    featured: true,
  },
  {
    id: "4",
    title: "Café da Manhã Especial com Torradas",
    slug: "cafe-manha-especial-torradas",
    description: "Torradas crocantes com coberturas variadas para um café da manhã completo.",
    image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&h=600&fit=crop",
    prepTime: 10,
    cookTime: 0,
    servings: 2,
    difficulty: "easy",
    ingredients: [
      { item: "Torradas Bauducco", amount: "6 unidades" },
      { item: "Cream cheese", amount: "100g" },
      { item: "Abacate", amount: "1 unidade" },
      { item: "Ovos", amount: "2 unidades" },
      { item: "Tomate cereja", amount: "100g" },
      { item: "Sal e pimenta", amount: "a gosto" },
    ],
    instructions: [
      "Prepare os ovos como preferir (mexido, poché ou cozido).",
      "Amasse o abacate com sal e pimenta.",
      "Monte as torradas: uma com cream cheese, uma com abacate e uma com ovo.",
      "Finalize com tomates cereja cortados ao meio.",
      "Tempere com sal, pimenta e ervas frescas.",
    ],
    relatedProducts: ["6", "7"],
    categories: ["cafe-da-manha"],
  },
  {
    id: "5",
    title: "Trufa de Chocottone",
    slug: "trufa-chocottone",
    description: "Trufas cremosas feitas com chocottone. Uma forma deliciosa de reaproveitar sobras.",
    image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800&h=600&fit=crop",
    prepTime: 20,
    cookTime: 0,
    servings: 20,
    difficulty: "easy",
    ingredients: [
      { item: "Chocottone Bauducco", amount: "500g" },
      { item: "Leite condensado", amount: "1 lata" },
      { item: "Chocolate em pó", amount: "3 colheres de sopa" },
      { item: "Granulado de chocolate", amount: "para decorar" },
    ],
    instructions: [
      "Desfie o chocottone em pedaços pequenos.",
      "Misture com o leite condensado e o chocolate em pó até formar uma massa homogênea.",
      "Enrole bolinhas com as mãos untadas.",
      "Passe no granulado de chocolate.",
      "Leve à geladeira por 1 hora antes de servir.",
    ],
    relatedProducts: ["2"],
    categories: ["sobremesas", "festas"],
  },
];

// Seed data for promotions
const promotions: Promotion[] = [
  {
    id: "1",
    code: "PRIMEIRA10",
    type: "percent",
    discountValue: 10,
    start: "2024-01-01",
    end: "2025-12-31",
    description: "10% de desconto na primeira compra",
    active: true,
  },
  {
    id: "2",
    code: "FRETE20",
    type: "fixed",
    discountValue: 20,
    start: "2024-01-01",
    end: "2025-12-31",
    conditions: { minPurchase: 100 },
    description: "R$ 20 de desconto no frete",
    active: true,
  },
  {
    id: "3",
    code: "NATAL15",
    type: "percent",
    discountValue: 15,
    start: "2024-11-01",
    end: "2024-12-31",
    conditions: { applicableProducts: ["1", "2", "8", "9"] },
    description: "15% de desconto em panettones",
    active: true,
  },
];

// Seed data for promo pages
const promoPages: PromoPage[] = [
  {
    id: "natal-2024",
    campaign: "natal",
    title: "Natal Bauducco",
    subtitle: "Os melhores panettones e chocottones para sua celebração. Até 30% OFF!",
    heroImage: "https://images.unsplash.com/photo-1512389142860-9c449e58a814?w=1920&q=80",
    heroCtaText: "Ver ofertas",
    heroCtaLink: "/products?tag=natal",
    sections: [],
    startDate: "2024-11-01",
    endDate: "2024-12-31",
    active: true,
  },
];

// Seed data for FAQs
const faqs: FAQ[] = [
  {
    id: "1",
    question: "Qual o prazo de entrega?",
    answer: "O prazo de entrega varia de acordo com a região. Para capitais, o prazo é de 2 a 5 dias úteis.",
    category: "entregas",
    order: 1,
  },
];

export interface IStorage {
  // Products
  getProducts(filters?: { category?: string; tag?: string; featured?: boolean; limit?: number; q?: string }): Promise<Product[]>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  getProductById(id: string): Promise<Product | undefined>;

  // Recipes
  getRecipes(filters?: { category?: string; difficulty?: string; featured?: boolean; q?: string }): Promise<Recipe[]>;
  getRecipeBySlug(slug: string): Promise<Recipe | undefined>;

  // Promotions
  getPromotions(): Promise<Promotion[]>;
  getPromotionByCode(code: string): Promise<Promotion | undefined>;

  // Promo Pages
  getPromoPage(campaign: string): Promise<PromoPage | undefined>;

  // FAQs
  getFaqs(category?: string): Promise<FAQ[]>;

  // Newsletter
  subscribeNewsletter(email: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private products: Product[] = products;
  private recipes: Recipe[] = recipes;
  private promotions: Promotion[] = promotions;
  private promoPages: PromoPage[] = promoPages;
  private faqs: FAQ[] = faqs;
  private newsletterSubscribers: Newsletter[] = [];

  async getProducts(filters?: { category?: string; tag?: string; featured?: boolean; limit?: number; q?: string }): Promise<Product[]> {
    let result = [...this.products];

    if (filters?.category) {
      result = result.filter(p => p.categories.includes(filters.category!));
    }

    if (filters?.tag) {
      result = result.filter(p => p.tags.includes(filters.tag!));
    }

    if (filters?.featured) {
      result = result.filter(p => p.featured === true);
    }

    if (filters?.q) {
      const query = filters.q.toLowerCase();
      result = result.filter(p => 
        p.name.toLowerCase().includes(query) ||
        p.shortDescription.toLowerCase().includes(query) ||
        p.tags.some(t => t.toLowerCase().includes(query))
      );
    }

    if (filters?.limit) {
      result = result.slice(0, filters.limit);
    }

    return result;
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return this.products.find(p => p.slug === slug);
  }

  async getProductById(id: string): Promise<Product | undefined> {
    return this.products.find(p => p.id === id);
  }

  async getRecipes(filters?: { category?: string; difficulty?: string; featured?: boolean; q?: string }): Promise<Recipe[]> {
    let result = [...this.recipes];

    if (filters?.category) {
      result = result.filter(r => r.categories.includes(filters.category!));
    }

    if (filters?.difficulty) {
      result = result.filter(r => r.difficulty === filters.difficulty);
    }

    if (filters?.featured) {
      result = result.filter(r => r.featured === true);
    }

    if (filters?.q) {
      const query = filters.q.toLowerCase();
      result = result.filter(r => 
        r.title.toLowerCase().includes(query) ||
        r.description.toLowerCase().includes(query)
      );
    }

    return result;
  }

  async getRecipeBySlug(slug: string): Promise<Recipe | undefined> {
    return this.recipes.find(r => r.slug === slug);
  }

  async getPromotions(): Promise<Promotion[]> {
    return this.promotions.filter(p => p.active);
  }

  async getPromotionByCode(code: string): Promise<Promotion | undefined> {
    return this.promotions.find(p => p.code.toUpperCase() === code.toUpperCase() && p.active);
  }

  async getPromoPage(campaign: string): Promise<PromoPage | undefined> {
    return this.promoPages.find(p => p.campaign === campaign && p.active);
  }

  async getFaqs(category?: string): Promise<FAQ[]> {
    if (category) {
      return this.faqs.filter(f => f.category === category).sort((a, b) => a.order - b.order);
    }
    return this.faqs.sort((a, b) => a.order - b.order);
  }

  async subscribeNewsletter(email: string): Promise<void> {
    if (!this.newsletterSubscribers.find(s => s.email === email)) {
      this.newsletterSubscribers.push({
        email,
        subscribedAt: new Date().toISOString(),
      });
    }
  }
}

export const storage = new MemStorage();
