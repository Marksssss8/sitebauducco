import { z } from "zod";

// Product Variant Schema
export const productVariantSchema = z.object({
  sku: z.string(),
  name: z.string(),
  weight: z.string(),
  price: z.number(),
  compareAtPrice: z.number().optional(),
  inventory: z.number(),
});

export type ProductVariant = z.infer<typeof productVariantSchema>;

// Nutritional Info Schema
export const nutritionalInfoSchema = z.object({
  servingSize: z.string(),
  calories: z.number(),
  totalFat: z.string(),
  saturatedFat: z.string(),
  transFat: z.string(),
  cholesterol: z.string(),
  sodium: z.string(),
  totalCarbs: z.string(),
  dietaryFiber: z.string(),
  sugars: z.string(),
  protein: z.string(),
});

export type NutritionalInfo = z.infer<typeof nutritionalInfoSchema>;

// Product Schema
export const productSchema = z.object({
  id: z.string(),
  sku: z.string(),
  name: z.string(),
  slug: z.string(),
  descriptionHtml: z.string(),
  shortDescription: z.string(),
  categories: z.array(z.string()),
  images: z.array(z.string()),
  variants: z.array(productVariantSchema),
  nutritionalInfo: nutritionalInfoSchema.optional(),
  dimensions: z.object({
    weight: z.number(),
    width: z.number(),
    height: z.number(),
    length: z.number(),
  }).optional(),
  tags: z.array(z.string()),
  availability: z.enum(["in_stock", "out_of_stock", "pre_order"]),
  featured: z.boolean().optional(),
  rating: z.number().optional(),
  reviewCount: z.number().optional(),
});

export type Product = z.infer<typeof productSchema>;

// Promotion Schema
export const promotionSchema = z.object({
  id: z.string(),
  code: z.string(),
  type: z.enum(["percent", "fixed", "bundle", "bxgy"]),
  discountValue: z.number(),
  start: z.string(),
  end: z.string(),
  conditions: z.object({
    minPurchase: z.number().optional(),
    maxUses: z.number().optional(),
    applicableProducts: z.array(z.string()).optional(),
  }).optional(),
  description: z.string(),
  active: z.boolean(),
});

export type Promotion = z.infer<typeof promotionSchema>;

// Cart Item Schema
export const cartItemSchema = z.object({
  sku: z.string(),
  productId: z.string(),
  name: z.string(),
  image: z.string(),
  variant: z.string(),
  quantity: z.number(),
  price: z.number(),
  compareAtPrice: z.number().optional(),
});

export type CartItem = z.infer<typeof cartItemSchema>;

// Cart Schema
export const cartSchema = z.object({
  id: z.string(),
  items: z.array(cartItemSchema),
  totals: z.object({
    subtotal: z.number(),
    discount: z.number(),
    shipping: z.number(),
    total: z.number(),
  }),
  appliedPromos: z.array(z.string()),
});

export type Cart = z.infer<typeof cartSchema>;

// Address Schema
export const addressSchema = z.object({
  id: z.string().optional(),
  name: z.string(),
  street: z.string(),
  number: z.string(),
  complement: z.string().optional(),
  neighborhood: z.string(),
  city: z.string(),
  state: z.string(),
  zipCode: z.string(),
  country: z.string().default("Brasil"),
  phone: z.string(),
  isDefault: z.boolean().optional(),
});

export type Address = z.infer<typeof addressSchema>;

// Shipping Option Schema
export const shippingOptionSchema = z.object({
  id: z.string(),
  name: z.string(),
  carrier: z.string(),
  price: z.number(),
  estimatedDays: z.number(),
  estimatedDelivery: z.string(),
});

export type ShippingOption = z.infer<typeof shippingOptionSchema>;

// Payment Method Schema
export const paymentMethodSchema = z.object({
  type: z.enum(["credit_card", "debit_card", "pix", "boleto", "mercadopago", "pagseguro"]),
  cardNumber: z.string().optional(),
  cardHolder: z.string().optional(),
  expiryDate: z.string().optional(),
  cvv: z.string().optional(),
  installments: z.number().optional(),
  pixKey: z.string().optional(),
});

export type PaymentMethod = z.infer<typeof paymentMethodSchema>;

// Order Schema
export const orderSchema = z.object({
  id: z.string(),
  userId: z.string().optional(),
  items: z.array(cartItemSchema),
  address: addressSchema,
  shipping: shippingOptionSchema,
  payment: paymentMethodSchema,
  totals: z.object({
    subtotal: z.number(),
    discount: z.number(),
    shipping: z.number(),
    total: z.number(),
  }),
  status: z.enum(["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"]),
  createdAt: z.string(),
  updatedAt: z.string(),
});

export type Order = z.infer<typeof orderSchema>;

// User Schema
export const userSchema = z.object({
  id: z.string(),
  name: z.string(),
  email: z.string().email(),
  phone: z.string().optional(),
  addresses: z.array(addressSchema),
  loyaltyPoints: z.number().default(0),
});

export type User = z.infer<typeof userSchema>;

// Recipe Schema
export const recipeSchema = z.object({
  id: z.string(),
  title: z.string(),
  slug: z.string(),
  description: z.string(),
  image: z.string(),
  prepTime: z.number(),
  cookTime: z.number(),
  servings: z.number(),
  difficulty: z.enum(["easy", "medium", "hard"]),
  ingredients: z.array(z.object({
    item: z.string(),
    amount: z.string(),
  })),
  instructions: z.array(z.string()),
  tips: z.array(z.string()).optional(),
  relatedProducts: z.array(z.string()),
  categories: z.array(z.string()),
  featured: z.boolean().optional(),
});

export type Recipe = z.infer<typeof recipeSchema>;

// Promo Page Schema (CMS-driven landing pages)
export const promoPageSchema = z.object({
  id: z.string(),
  campaign: z.string(),
  title: z.string(),
  subtitle: z.string().optional(),
  heroImage: z.string(),
  heroCtaText: z.string(),
  heroCtaLink: z.string(),
  sections: z.array(z.object({
    type: z.enum(["banner", "products", "text", "cta"]),
    content: z.any(),
  })),
  startDate: z.string(),
  endDate: z.string(),
  active: z.boolean(),
});

export type PromoPage = z.infer<typeof promoPageSchema>;

// FAQ Schema
export const faqSchema = z.object({
  id: z.string(),
  question: z.string(),
  answer: z.string(),
  category: z.string(),
  order: z.number(),
});

export type FAQ = z.infer<typeof faqSchema>;

// Newsletter Subscription Schema
export const newsletterSchema = z.object({
  email: z.string().email(),
  subscribedAt: z.string(),
});

export type Newsletter = z.infer<typeof newsletterSchema>;

// Analytics Event Schema
export const analyticsEventSchema = z.object({
  event: z.enum([
    "view_item_list",
    "select_item",
    "view_item",
    "add_to_cart",
    "remove_from_cart",
    "begin_checkout",
    "add_shipping_info",
    "add_payment_info",
    "purchase",
    "coupon_applied",
    "search",
  ]),
  params: z.record(z.any()),
  timestamp: z.string(),
});

export type AnalyticsEvent = z.infer<typeof analyticsEventSchema>;

// Insert Schemas for API requests
export const insertCartItemSchema = cartItemSchema.omit({});
export type InsertCartItem = z.infer<typeof insertCartItemSchema>;

export const insertAddressSchema = addressSchema.omit({ id: true });
export type InsertAddress = z.infer<typeof insertAddressSchema>;

export const applyPromoSchema = z.object({
  code: z.string(),
});
export type ApplyPromo = z.infer<typeof applyPromoSchema>;

export const checkoutSchema = z.object({
  cartId: z.string(),
  address: addressSchema,
  shippingOptionId: z.string(),
  payment: paymentMethodSchema,
});
export type CheckoutData = z.infer<typeof checkoutSchema>;

// Search Query Schema
export const searchQuerySchema = z.object({
  query: z.string().optional(),
  category: z.string().optional(),
  minPrice: z.number().optional(),
  maxPrice: z.number().optional(),
  tags: z.array(z.string()).optional(),
  page: z.number().default(1),
  limit: z.number().default(12),
  sort: z.enum(["relevance", "price_asc", "price_desc", "newest"]).optional(),
});
export type SearchQuery = z.infer<typeof searchQuerySchema>;

// CEP Lookup Response
export const cepResponseSchema = z.object({
  cep: z.string(),
  street: z.string(),
  neighborhood: z.string(),
  city: z.string(),
  state: z.string(),
});
export type CEPResponse = z.infer<typeof cepResponseSchema>;
